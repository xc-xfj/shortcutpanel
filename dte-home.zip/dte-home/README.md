dte pad Home a nice user experience for touchscreens.
