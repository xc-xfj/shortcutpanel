var shortCutSetting_cellWidth = 80
var shortCutSetting_cellHeight = 122
var shortCutSetting_iconTopMargin = 10
var shortCutSetting_textTopMargin = 8
var shortCutSetting_maskLength = 60
var shortCutSetting_iconSize = 36
var shortCutSetting_positionOffset = 100

var shortCutPanel_width = 340
var shortCutPanel_cellCntPerLine = 4
var shortCutPanel_timeDispalyAreaWidth = 100
var shortCutPanel_timeDispalyAreaHeight = 48
var shortCutPanel_dateDispalyAreaTopMargin = 8
var shortCutPanel_shortcutPanelTopMargin = 34
var shortCutPanel_powerAreaWidth = 48
var shortCutPanel_powerAreaHeight = 48
var shortCutPanel_powerAreaRadius = 8

var statusBar_timeAreaWidth = 40
var statusBar_height = 40
var statusBar_iconSize = 20
var statusBar_iconMargin = 10

var gaussianBlur_radius = 50

var subItemWidth = 320
var subItemHeight = 486
var subItemRadius = 20

var miniScale = 0.8
var maxScale = 1
var miniOpacity = 0
var maxOpacity = 1
