.pragma library

var instance

var compositor
