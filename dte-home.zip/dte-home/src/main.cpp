/*
 * Copyright (C) 2020 ~ 2021 Uniontech Software Technology Co.,Ltd.
 *
 * Author:     xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * Maintainer: xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <QFont>
#include <QQmlEngine>
#include <QQmlContext>
#include <QScreen>
#include <QTranslator>
#include <QQmlApplicationEngine>

#include <homewindow.h>
#include <homeapplication.h>
#include <lipstickqmlpath.h>

#include "fileutils.h"
#include "shortcutmodel.h"
#include "enumtype.h"
#include "cellmanager.h"
#include "shortcutadaptor.h"
#include "shortcutmanager.h"
#include "constant.h"
#include "notifymanager.h"
#include "notifications_dbus_adaptor.h"
#include "notifycenteradaptor.h"

int main(int argc, char **argv)
{
    HomeApplication app(argc, argv, QString());

    QTranslator myappTranslator;
    myappTranslator.load(QStringLiteral("/usr/share/lipstick-deepin-home/translations/deepin-home_%1.qm").arg(QLocale::system().name()));
    app.installTranslator(&myappTranslator);

    NotifyManager notifyManager(nullptr, app.engine());
    DBusNotifyCenterAdaptor notify(&notifyManager);
    NotificationsDBusAdaptor adapter(&notifyManager);

    QmlPath::append("/home/xiechuan/Documents/down/dte-home/src/qml");
    QGuiApplication::setFont(QFont("Open Sans"));

    FileUtils *fileUtils = new FileUtils();

    app.setCompositorPath("/home/xiechuan/Documents/down/dte-home/src/qml/compositor.qml");
    Qt::ScreenOrientation nativeOrientation = app.primaryScreen()->nativeOrientation();
    QByteArray v = qgetenv("GLACIER_NATIVEORIENTATION");
    if (!v.isEmpty()) {
        switch (v.toInt()) {
        case 1:
            nativeOrientation = Qt::PortraitOrientation;
            break;
        case 2:
            nativeOrientation = Qt::LandscapeOrientation;
            break;
        case 4:
            nativeOrientation = Qt::InvertedPortraitOrientation;
            break;
        case 8:
            nativeOrientation = Qt::InvertedLandscapeOrientation;
            break;
        default:
            nativeOrientation = app.primaryScreen()->nativeOrientation();
        }
    }
    if (nativeOrientation == Qt::PrimaryOrientation)
        nativeOrientation = app.primaryScreen()->primaryOrientation();
    app.engine()->rootContext()->setContextProperty("nativeOrientation", nativeOrientation);
    app.engine()->rootContext()->setContextProperty("fileUtils", fileUtils);
    app.engine()->addImportPath("/usr/lib/qt/qml");

    CellManager newCellManager;
    app.engine()->rootContext()->setContextProperty("mewCellManager", &newCellManager);


    qmlRegisterType<ShortcutModel>("com.deepin.dte", 1, 0, "ShortcutModel");
    qmlRegisterType<EnumType>("EnumType", 1, 0, "EnumType");
    qmlRegisterType<CellManager>("cellManager", 1, 0, "CellManager");

    app.setQmlPath("/home/xiechuan/Documents/down/dte-home/src/qml/topmenu/PulldownPanel.qml");

    // Give these to the environment inside the lipstick homescreen
    // Fixes a bug where some applications wouldn't launch, eg. terminal or browser
    setenv("EGL_PLATFORM", "wayland", 1);
    setenv("QT_QPA_PLATFORM", "wayland", 1);
    setenv("QT_WAYLAND_DISABLE_WINDOWDECORATION", "1", 1);

    app.mainWindowInstance()->showFullScreen();

    QDBusConnection session = QDBusConnection::sessionBus();
    if (!session.registerService(DDESESSIONCC::SHELL_SHORTCUT_DBUS_NAME)) {
        qWarning() << QString("Check if %1 service exists").arg(DDESESSIONCC::SHELL_SHORTCUT_DBUS_NAME);
    }

    ShortcutManager shortcutManager;
    DBusShortcutAdaptor shortcutAdapt(&shortcutManager);
    QDBusConnection::sessionBus().registerObject(DDESESSIONCC::SHELL_SHORTCUT_DBUS_PATH, &shortcutManager);

    return app.exec();
}

