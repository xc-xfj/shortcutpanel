/*
   * Copyright (C) 2020 ~ 2021 Uniontech Software Technology Co.,Ltd.
   *
   * Author:     xiechuan <xiechuan@uniontech.com>
   *
   * Maintainer: xiechuan <xiechuan@uniontech.com>
   *
   * This program is free software: you can redistribute it and/or modify
   * it under the terms of the GNU General Public License as published by
   * the Free Software Foundation, either version 3 of the License, or
   * any later version.
   *
   * This program is distributed in the hope that it will be useful,
   * but WITHOUT ANY WARRANTY; without even the implied warranty of
   * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   * GNU General Public License for more details.
   *
   * You should have received a copy of the GNU General Public License
   * along with this program.  If not, see <http://www.gnu.org/licenses/>.
   */

#include "shortcutmodel.h"
#include "constant.h"

#include <QFileInfo>
#include <QDir>
#include <QDebug>
#include <QGSettings/QGSettings>
#include <QDBusServiceWatcher>
#include <QJsonParseError>
#include <QJsonObject>
#include <QDBusConnection>
#include <QDBusConnectionInterface>

#include <DDesktopEntry>
#include <DGuiApplicationHelper>

DCORE_USE_NAMESPACE
DGUI_USE_NAMESPACE

const QString jsonPath = "/etc/due-shell/json/";

/**
 * @brief ShortcutModel::ShortcutModel 快捷区域视图模型类
 * 当QGSettings值发生改变时,更新当前快捷区域模型视图
 * 当软件卸载时,判断当前快捷设置归属软件是否存在,若不存在则
 * 删除当前快捷设置,更新配置
 * @param parent
 */
ShortcutModel::ShortcutModel(QObject *parent)
    : QAbstractListModel(parent)
    , m_gsettings(new QGSettings(DDESESSIONCC::DTE_SHELL_GSETTINGS_NAME
                                 , DDESESSIONCC::DTE_SHELL_GSETTINGS_PATH, this))
    , m_serviceWatcher(new QDBusServiceWatcher(this))
{
    m_roleNames.insert(EnumType::CellName, "clName");
    m_roleNames.insert(EnumType::CellIconName, "clIconName");
    m_roleNames.insert(EnumType::CellDesktop, "clDesktop");
    m_roleNames.insert(EnumType::CellCommand, "clCommand");
    m_roleNames.insert(EnumType::ShortcutType, "clType");
    initData();
}

int ShortcutModel::rowCount(const QModelIndex &parent) const
{
    return m_preLoadList.count() + m_plugInList.count() + m_addinList.count();
}

QVariant ShortcutModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
        return QVariant();

    int row = index.row();
    if (row > rowCount() - 1)
        return QVariant();

    CellItem item;
    int preCount = m_preLoadList.count();
    int plugInCount = m_plugInList.count();

    if (row < preCount) {
        item = m_preLoadList[row];
    } else if (row >= preCount && row < preCount + plugInCount) {
        item = m_plugInList[row - preCount];
    } else{
        item = m_addinList[row - preCount - plugInCount];
    }

    switch (role) {
    case EnumType::CellName:
        return item.cellName;
    case EnumType::CellIconName:
        return item.cellIconName;
    case EnumType::CellDesktop:
        return item.cellDesktopName;
    case EnumType::ShortcutType:
        return item.cellType;
    case EnumType::CellCommand:
        return item.cellCommand;
    default:
        return QVariant();
    }
}

bool ShortcutModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    int listIndex = index.row() - m_preLoadList.count();
    int count = m_plugInList.count();

    if (0 == count || listIndex < 0 || listIndex > count - 1)
        return false;

    m_plugInList[listIndex].cellIconName = value.toString();
    Q_EMIT dataChanged(index, index);
    return true;
}

QHash<int, QByteArray> ShortcutModel::roleNames() const
{
    return m_roleNames;
}

/**
 * @brief initPreData 初始化数据
 */
void ShortcutModel::initData()
{
    // 初始化预设数据
    m_preLoadList.append(CellItem(tr("WLAN"), "wifi_normal", EnumType::TypeWireless));
    m_preLoadList.append(CellItem(tr("Bluetooth"), "bluetooth_normal", EnumType::TypeBluetooth));
    m_preLoadList.append(CellItem(tr("Hotspot"), "hotspot_normal", EnumType::TypeHotSpot));
    m_preLoadList.append(CellItem(tr("Lock screen"), "lock_normal", EnumType::TypeLockScreen));
    m_preLoadList.append(CellItem(tr("DND"), "dnd_normal", EnumType::TypeDND));
    m_preLoadList.append(CellItem((" "), "rotation_normal", EnumType::TypeRotation));

    parseJsonFile(jsonPath);
    parseConfig();
    initConnect();
}

/**
 * @brief parseConfig 解析配置
 */
void ShortcutModel::parseConfig()
{
    // 解析配置文件加载快捷设置
    QStringList settingList = m_gsettings->get(DDESESSIONCC::ShortcutSettings).toStringList();
    QFileInfo file(DDESESSIONCC::ShortcutDirPath);
    if (!file.isDir())
        return;

    QFileInfo info;
    QString path, shortcutName, shortcutIcon, command;

    beginResetModel();
    m_addinList.clear();

    foreach(const QString &name, settingList) {
        path = DDESESSIONCC::ShortcutDirPath + name + ".desktop";
        info.setFile(path);
        if (!info.exists()) {
            qWarning() << "check " << name << "is exists in " << DDESESSIONCC::ShortcutDirPath;
            continue;
        }

        // 解析desktop文件中的内容
        DDesktopEntry entry(path);
        shortcutName = entry.ddeDisplayName();
        shortcutIcon = entry.rawValue("Icon");
        command = entry.rawValue("Exec");
        if (rowCount() < m_maxItemCount)
            m_addinList.append(CellItem(shortcutName, shortcutIcon, EnumType::TypeApplication, name, command));
    }
    endResetModel();
}

void ShortcutModel::initConnect()
{
    connect(m_gsettings, &QGSettings::changed, this, [this](const QString &key){
        if ("shortcutsettings" != key)
            return;

        parseConfig();
    });
}

/**
 * @brief updateData 当快捷设置插件目录发生改变时更新快捷区域视图模型数据
 */
void ShortcutModel::updateData()
{
    QFileInfo info;
    QString path;
    int count = 0;
    int addinCount = m_addinList.count();
    QStringList settingList = m_gsettings->get(DDESESSIONCC::ShortcutSettings).toStringList();
    count = settingList.count();

    if (addinCount != count)
        qWarning() << DDESESSIONCC::ShortcutSettings + "config data is inconsistent with pluginAddinModel data";

    beginResetModel();
    foreach (auto desktopName, settingList) {
        path = DDESESSIONCC::ShortcutDirPath + desktopName + ".desktop";
        info.setFile(path);
        if (!info.exists()) {
            settingList.removeOne(desktopName);
            // 确保desktop名一致，避免因为索引误删
            for (auto item : m_addinList) {
                if (desktopName == item.cellDesktopName)
                    m_addinList.removeOne(item);
            }
        }
    }
    endResetModel();
    m_gsettings->set(DDESESSIONCC::ShortcutSettings, QVariant::fromValue(settingList));
}

/**
 * @brief ShortcutModel::parseJsonFile 解析应用程序对应的JSON文件
 * 需要在状态栏和下拉面板快捷设置里显示的应用程序，在预安装的时候，会将其对应的JSON文件放在/etc/due-shell/json/文件夹下
 * @param filePath 参数
 * @return
 */
void ShortcutModel::parseJsonFile(const QString &path)
{
    QFileInfo file(path);
    if (!file.isDir())
        return;

    QDir dir(path);
    dir.setFilter(QDir::Files);
    QFileInfoList fileInfoList = dir.entryInfoList();

    beginResetModel();
    m_plugInList.clear();

    foreach(const QFileInfo &fileInfo, fileInfoList) {
        QString fileName = fileInfo.fileName();
        QString appName = fileInfo.baseName();
        QFile loadFile(path + fileName);
        if (!loadFile.open(QIODevice::ReadOnly)) {
            qDebug() << "open json file failed" << endl;
            continue;
        }
        QByteArray allData = loadFile.readAll();
        loadFile.close();

        QJsonParseError json_error;
        QJsonDocument jsonDoc(QJsonDocument::fromJson(allData, &json_error));
        if (QJsonParseError::NoError != json_error.error) {
            qDebug() << "json error!";
            continue;
        }

        QJsonObject rootObj = jsonDoc.object();
        QJsonObject subObj;
        QJsonObject appInfoObj;

        // JSON文件不包含"dbus info"字段，或则同时不包含"status bar"和"drop down"字段，则为无效文件
        if (!rootObj.contains("dbus info")
                || (!rootObj.contains("status bar") && !rootObj.contains("drop down")))
            continue;

        // 从json文件解析desktop文件获取快捷设置名
        QString pluginName;
        appInfoObj = rootObj.value("app info").toObject();
        QString desktopPath = appInfoObj["desktop_path"].toString();
        if (!desktopPath.isEmpty()) {
            DDesktopEntry entry(desktopPath);
            pluginName = entry.ddeDisplayName();
        }

        // 从json文件解析出dbus服务相关的属性
        subObj = rootObj.value("dbus info").toObject();
        QString service = subObj["dbus_service"].toString();
        QString path = subObj["dbus_path"].toString();
        QString interface = subObj["dbus_interface"].toString();

        QString properties;

        if (rootObj.contains("drop down")) {
            subObj = rootObj.value("drop down").toObject();
            properties = subObj["dbus_properties"].toString();
            CellItem item(pluginName, subObj["default_icon"].toString(), EnumType::TypePlugin, "", subObj["command"].toString());
            m_plugInList.append(item);

            auto req = QDBusConnection::sessionBus().interface()->isServiceRegistered(service);
            // 刚初始化的时候，由于应用都还未开启，这块逻辑99.9%是走不进去的，但是为了保险起见，还是加上了。
            if (req.value()) {
                item.refreshIcon(subObj["action_icon"].toString());
            } else { // 正常情况应该是走进这个分支
                // TODO: 当有多个预装应用的时候，这块要优化。此实现方法只是监听一个服务的注册。

                m_serviceWatcher->setConnection(QDBusConnection::sessionBus());
                m_serviceWatcher->addWatchedService(service);
                // 应用开启时，才会去dbus上注册服务信息。所以检测到相应dbus服务注册时，就可以知道应用已经开启。
                // 此时可能需要更换下拉面板应用快捷设置中对应的图标
                connect(m_serviceWatcher, &QDBusServiceWatcher::serviceRegistered, this, [=]() {
                    if (m_plugInList.isEmpty())
                        return;

                    auto index = this->index(m_preLoadList.count(), 0 , QModelIndex());
                    this->setData(index, subObj["action_icon"].toString(), EnumType::CellIconName);
                });
            }

            auto updateDefaultIcon = [=](DGuiApplicationHelper::ColorType type){
                if (m_plugInList.isEmpty())
                    return;

                auto index = this->index(m_preLoadList.count(), 0 , QModelIndex());
                QString iconPath;
                if (DGuiApplicationHelper::DarkType == type)
                    iconPath = subObj["dark_default_icon"].toString();
                else
                    iconPath = subObj["default_icon"].toString();

                this->setData(index, iconPath, EnumType::CellIconName);
            };

            updateDefaultIcon(DGuiApplicationHelper::instance()->themeType());
            // 当应用的dbus服务注销时，即应用执行结束，此时需要更换下拉面板应用快捷设置中对应的图标
            connect(m_serviceWatcher, &QDBusServiceWatcher::serviceUnregistered, this, [=]() {
                updateDefaultIcon(DGuiApplicationHelper::instance()->themeType());
            });

            connect(DGuiApplicationHelper::instance(), &DGuiApplicationHelper::themeTypeChanged, this, [=](DGuiApplicationHelper::ColorType themeType){
                updateDefaultIcon(themeType);
            });
        }
    }
    endResetModel();
}
