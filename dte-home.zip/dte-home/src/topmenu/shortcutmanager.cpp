/*
 * Copyright (C) 2020 ~ 2021 Uniontech Software Technology Co.,Ltd.
 *
 * Author:     xiechuan <xiechuan@uniontech.com>
 *
 * Maintainer: xiechuan <xiechuan@uniontech.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "shortcutmanager.h"
#include "constant.h"

#include <QVariant>
#include <QGSettings/QGSettings>
#include <QTimer>

ShortcutManager::ShortcutManager(QObject *parent)
    : QObject(parent)
    , m_gsettings(new QGSettings(DDESESSIONCC::DTE_SHELL_GSETTINGS_NAME
                                 , DDESESSIONCC::DTE_SHELL_GSETTINGS_PATH, this))
{

}

/**
 * @brief setShortcutSettings 设置快捷设置配置
 * @param settings
 */
void ShortcutManager::setShortcutSettings(const QStringList &settings)
{
    m_gsettings->set(DDESESSIONCC::ShortcutSettings, QVariant::fromValue(settings));
}

/**
 * @brief shortcutSettings 返回所有快捷设置
 * @return
 */
QStringList ShortcutManager::shortcutSettings()
{
    return m_gsettings->get(DDESESSIONCC::ShortcutSettings).toStringList();
}

/**
 * @brief add 添加desktop对应的快捷设置(desktop只是文件名)
 * @param desktop
 */
void ShortcutManager::add(const QString &desktop)
{
    QStringList list = m_gsettings->get(DDESESSIONCC::ShortcutSettings).toStringList();
    list << desktop;
    m_gsettings->set(DDESESSIONCC::ShortcutSettings, QVariant::fromValue(list));
}

/**
 * @brief insert 插入快捷设置
 * @param index 索引位置
 * @param desktop desktop文件名
 */
void ShortcutManager::insert(int index, const QString &desktop)
{
    QStringList list = m_gsettings->get(DDESESSIONCC::ShortcutSettings).toStringList();
    if (index > list.count() - 1)
        return;

    list.insert(index, desktop);
    m_gsettings->set(DDESESSIONCC::ShortcutSettings, QVariant::fromValue(list));
}

/**
 * @brief clear 清除所有快捷设置配置
 */
void ShortcutManager::clear()
{
    m_gsettings->set(DDESESSIONCC::ShortcutSettings, QVariant::fromValue(QStringList()));
}

/**
 * @brief remove 删除desktop对应的快捷设置
 * @param desktop desktop文件名
 * @return 是否删除成功
 */
bool ShortcutManager::remove(const QString &desktop)
{
    QStringList list = m_gsettings->get(DDESESSIONCC::ShortcutSettings).toStringList();
    if (!list.contains(desktop))
        return false;

    list.removeOne(desktop);
    m_gsettings->set(DDESESSIONCC::ShortcutSettings, QVariant::fromValue(list));
    return true;
}

/**
 * @brief remove 删除索引为index的快捷设置
 * @param index
 * @return 返回是否删除成功
 */
bool ShortcutManager::remove(int index)
{
    QStringList list = m_gsettings->get(DDESESSIONCC::ShortcutSettings).toStringList();
    if (index > list.count() - 1)
        return false;

    list.removeAt(index);
    m_gsettings->set(DDESESSIONCC::ShortcutSettings, QVariant::fromValue(list));
    return true;
}
