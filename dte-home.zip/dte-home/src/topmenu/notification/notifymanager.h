/*
 * Copyright (C) 2020 ~ 2021 Uniontech Software Technology Co.,Ltd.
 *
 * Author:     xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * Maintainer: xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef NOTIFYMANAGER_H
#define NOTIFYMANAGER_H

#include "constant.h"

#include <QPointer>

class NotifyWindow;
class ShellInterface;
class Persistence;
class NotifySettings;
class LockNotifyModel;
class NotifyCenterModel;
class QQmlEngine;
class QDBusVariant;
class QDBusInterface;
class QQmlContext;

struct AppNotifyProperty {
    bool isAllowNotify;
    bool isShowInNotifyCenter;
    bool isLockShowNotify;
    bool isShowNotifyPreview;
    bool isNotificationSound;
};

struct SysNotifyProperty {
    bool isDoNotDisturb;
    bool isTimeSlot;
    bool isAppsInFullscreen;
    bool isConnectedProjector;
    bool isScreenLocked;
    bool isShowIconOnDock;
    QString StartTime;
    QString EndTime;
};

class NotifyManager : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString allSetting READ getAllSetting)
    Q_PROPERTY(QString systemSetting READ getSystemSetting)

public:
    explicit NotifyManager(QObject *parent = nullptr, QQmlEngine *engine = nullptr);
    ~NotifyManager();

    enum ClosedReason {
        Expired = 1,
        Dismissed = 2,
        Closed = 3,
        Unknown = 4
    };

Q_SIGNALS:
    // Standard Notifications dbus implementation
    void ActionInvoked(uint, const QString &);
    void NotificationClosed(uint, uint);

    // Extra DBus APIs
    void RecordAdded(const QString &);
    void AppInfoChanged(const QString &id, uint item, QDBusVariant var);
    void SystemInfoChanged(uint item, QDBusVariant var);
    void AppAddedSignal(const QString &id);
    void AppRemovedSignal(const QString &id);

    void appAdded(QString appName);
    void appRemoved(QString appName);
    void appSettingChanged(QString Settings);
    void systemSettingChanged(QString Settings);

public Q_SLOTS:
    void CloseNotification(uint);
    QStringList GetCapabilities();
    QString GetServerInformation(QString &, QString &, QString &);
    uint Notify(const QString &, uint replacesId, const QString &, const QString &, const QString &, const QStringList &, const QVariantMap, int);

    // Extra DBus APIs
    QString GetAllRecords();
    QString GetRecordById(const QString &id);
    QString GetRecordsFromId(int rowCount, const QString &offsetId);
    void RemoveRecord(const QString &id);
    void ClearRecords();
    void Toggle();
    uint recordCount();
    QStringList GetAppList();

    QDBusVariant GetAppInfo(const QString id, uint item);
    QDBusVariant GetSystemInfo(uint item);
    void SetAppInfo(const QString id, uint item, const QDBusVariant var);
    void SetSystemInfo(uint item, const QDBusVariant var);

    QString getAllSetting();
    void setAllSetting(const QString settings);
    QString getAppSetting(QString appName);
    void setAppSetting(const QString settings);
    QString getSystemSetting();
    void setSystemSetting(QString settings);

private:
    AppNotifyProperty appNotifyProperty(const QString &appName);
    void createBanner(EntityPtr entiy, int timeout);
    void pushBanner(EntityPtr notify);
    void registerAsService();
    bool isDoNotDisturb();
    void updateSysNotifyProperty();
    void initConnect();
    void updateBannerPara(QQmlContext *context, EntityPtr entiy);
    bool isInTransit(EntityPtr notification) const;
    void addNotifyInLock(EntityPtr notification);
    void addInNotifyCenter(EntityPtr notification);

private:
    Persistence *m_persistence;
    NotifyCenterModel *m_notifyCenterModel;     // 通知中心模型
    LockNotifyModel *m_lockNotifyModel;         // 锁屏通知模型
    QList<QPointer<NotifyWindow>> m_bannerList; // 横幅窗口列表
    ShellInterface *m_shellInter;
    NotifySettings *m_notifySettings;
    SysNotifyProperty m_sysNotifyProperty;
    QDBusInterface *m_sessionPowerInter;
};

#endif // NOTIFYMANAGER_H
