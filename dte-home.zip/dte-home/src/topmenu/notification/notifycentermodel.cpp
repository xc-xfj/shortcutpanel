/*
 * Copyright (C) 2020 ~ 2021 Uniontech Software Technology Co.,Ltd.
 *
 * Author:     xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * Maintainer: xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "constant.h"
#include "public_func.h"
#include "notifycentermodel.h"
#include "persistence.h"
//#include "shellinterface.h"

/**
 * @brief NotifyCenterModel::NotifyCenterModel 通知中心数据模型
 * 通知中心数据模型继承自锁屏通知模型，其继承锁屏通知的特性，同事增加了
 * 对数据库的处理
 * @param parent
 * @param database 数据库指针
 */
NotifyCenterModel::NotifyCenterModel(QObject *parent, Persistence *database)
    : LockNotifyModel (parent)
    , m_database(database)
//    , m_shellInter(new ShellInterface(DDESESSIONCC::SHELL_DBUS_NAME
//                             , DDESESSIONCC::SHELL_DBUS_PATH
//                             , QDBusConnection::sessionBus(), this))
{
    initData();
}

void NotifyCenterModel::addLockNotifyList(LockNotifyModel *lockModel)
{
    if (!lockModel)
        return;

    QList<EntityPtr> allLockNotify = lockModel->allNotify();

    if (allLockNotify.isEmpty())
        return;

    for (auto item : allLockNotify) {
        if (item->isShowInNotifyCenter()) {
            addNotify(item);
        }
    }
}

void NotifyCenterModel::removeNotifyFromeDB(int row)
{
    EntityPtr entity = entityByRow(row);
    if (!entity)
        return;

    m_database->removeEntity(entity->appName(), QString::number(entity->id()));
}

void NotifyCenterModel::removeAppGroupFromeDB(EntityPtr entity)
{
    const QString appName = entity->appName();

    if (m_preNotifyList.count() < 5) {
        bool searchResult = false;
        for (auto item : m_preNotifyList) {
            if (item->appName() == appName) {
                searchResult = true;
                break;
            }
        }

        if (!searchResult) {
            m_database->deleteTable(appName);
            return;
        }
    }

    for (auto listItem : m_notifyGroupList) {
        if (appName == listItem.appName) {
            for (auto showEntity : listItem.showList) {
                m_database->removeEntity(showEntity->appName(), QString::number(showEntity->id()));
            }
            for (auto hideEntity : listItem.hideList) {
                m_database->removeEntity(hideEntity->appName(), QString::number(hideEntity->id()));
            }
            break;
        }
    }
}

void NotifyCenterModel::removeAllFromeDB()
{
    m_database->removeAll();
}

void NotifyCenterModel::readNotify(const QString &appName, int row)
{
    resetFlickable();
//    if (!m_shellInter->isValid()) {
//        qCritical() << "launchApp failed, start interface is invalid!";
//        return;
//    }

    EntityPtr entity = entityByRow(row);
    removeNotify(row);
//    m_shellInter->Hide();
    openDesktopApp(entity);
}

void NotifyCenterModel::notifyActionInvoke(const QString &actionid, const QVariantMap &hints, int row)
{
//    m_shellInter->Hide();

    actionInvoke(entityByRow(row), actionid, hints);
    removeNotify(row);
}

/**
 * @brief NotifyCenterModel::initData 初始化界面，从数据库中读取数据，根据规则折叠
 */
void NotifyCenterModel::initData()
{
    QList<EntityPtr> notifications =  m_database->getAllNotify();

    // 消息组排序
    qSort(notifications.begin(), notifications.end(), [ = ](const EntityPtr& ptr1, const EntityPtr& ptr2){
        return ptr1->ctime().toLongLong() > ptr2->ctime().toLongLong();
    });

    foreach (auto notify, notifications) {
        addAppData(notify);
    }

    refreshFold();
}
