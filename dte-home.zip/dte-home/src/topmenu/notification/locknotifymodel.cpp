/*
 * Copyright (C) 2020 ~ 2021 Uniontech Software Technology Co.,Ltd.
 *
 * Author:     xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * Maintainer: xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "locknotifymodel.h"
//#include "dueshellmanager.h"

#include <QDateTime>
#include <QGSettings/QGSettings>
#include <QDBusMessage>

/**
 * @brief LockNotifyModel::LockNotifyModel 锁屏通知数据模型
 * 数据显示结构如下m_preNotifyList显示在前
 * *********************************
 * *       m_preNotifyList         *
 * *********************************
 * *       m_notifyGroupList       *
 * *********************************
 *
 * 为了简化间距的逻辑，间距存在每个应用的前面，使用ListItem的showList[0]索引
 * @param parent
 */
LockNotifyModel::LockNotifyModel(QObject *parent)
    : QAbstractListModel (parent)
    , m_currentExpandCount(-1)
//    , m_timedateInter(new Timedate("com.deepin.daemon.Timedate"
//                                   , "/com/deepin/daemon/Timedate"
//                                   , QDBusConnection::sessionBus(), this))
    , m_gsettings(new QGSettings(DDESESSIONCC::NOTIFY_GSETTING_NAME
                                 , DDESESSIONCC::NOTIFY_GSETTING_PATH, this))
    , m_flickedRow(-1)
{
    m_roleNames.insert(EnumType::AppName, "ntAppName");
    m_roleNames.insert(EnumType::AppIcon, "ntAppIcon");
    m_roleNames.insert(EnumType::NotifyTime, "ntTime");
    m_roleNames.insert(EnumType::Summary, "ntSummary");
    m_roleNames.insert(EnumType::Body, "ntBody");
    m_roleNames.insert(EnumType::Actions, "ntActions");
    m_roleNames.insert(EnumType::ActionsId, "ntActionsId");
    m_roleNames.insert(EnumType::Hints, "ntHints");
    m_roleNames.insert(EnumType::NotifyState, "ntState");
    m_roleNames.insert(EnumType::NotifyZorder, "ntZorder");
    m_roleNames.insert(EnumType::ExpandParentRow, "ntExpandParentRow");
    m_roleNames.insert(EnumType::ParentPosY, "ntParentPosY");
    m_roleNames.insert(EnumType::IsBlank, "ntIsBlank");
    m_roleNames.insert(EnumType::IsFlicked, "ntIsFlicked");
    m_roleNames.insert(EnumType::ShowPreview, "ntShowPreview");

    m_flickVector.append(EnumType::IsFlicked);

//    connect(m_timedateInter, &Timedate::NTPChanged, this, &LockNotifyModel::updateBubbleTime);
}

/**
 * @brief LockNotifyModel::allNotify 返回模型中所有的消息
 * @return 消息列表
 */
QList<EntityPtr> LockNotifyModel::allNotify()
{
    QList<EntityPtr> notifycations;

    if (m_preNotifyList.isEmpty() && m_notifyGroupList.isEmpty())
        return  notifycations;

    int count = m_notifyGroupList.count();

    notifycations.append(m_preNotifyList);

    for(int i = 0; i < count; i++) {
        notifycations.append(m_notifyGroupList[i].showList);
        notifycations.append(m_notifyGroupList[i].hideList);
    }

    return notifycations;
}

/**
 * @brief LockNotifyModel::rowCount 返回当前显示消息的总数
 * @param parent
 * @return 消息总数
 */
int LockNotifyModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent)

    int count = 0;
    count += m_preNotifyList.size();
    foreach (auto item, m_notifyGroupList) {
        count += item.showList.size();
    }
    return count;
}

QVariant LockNotifyModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() > (rowCount(QModelIndex()) - 1)) {
        return QVariant();
    }

    QStringList idList, actionList;
    EntityPtr entity = entityByRow(index.row());

    if (!entity)
        return QVariant();

    actionInfomation(entity->actions(), idList, actionList);

    if (entity) {
        switch (role) {
        case EnumType::AppName: {
            QString appname = entity->appName();
            return QVariant::fromValue(entity->appName());
        }
        case EnumType::AppIcon:
            return QVariant::fromValue(entity->appIcon());
        case EnumType::NotifyTime:
            return QVariant::fromValue(entity->ctime());
        case EnumType::Summary:
            return QVariant::fromValue(entity->summary());
        case EnumType::Body:
            return QVariant::fromValue(entity->body());
        case EnumType::Actions:
            return QVariant::fromValue(actionList);
        case EnumType::ActionsId:
            return QVariant::fromValue(idList);
        case EnumType::Hints:
            return entity->hints();
        case EnumType::NotifyState:
            return entity->state();
        case EnumType::NotifyZorder:
            return QVariant::fromValue(entity->zorder());
        case EnumType::ExpandParentRow:
            return QVariant::fromValue(entity->expandParentRow());
        case EnumType::ParentPosY:
            return QVariant::fromValue(entity->parentPosY());
        case EnumType::IsBlank:
            return QVariant::fromValue(entity->isTitle());
        case EnumType::IsFlicked:
            return entity->isFlicked();
        case EnumType::ShowPreview:
            return entity->isShowPreview();
        }
    }

    return QVariant();
}

/**
 * @brief LockNotifyModel::appFirstNotifyRow 获取第一个应用名为appName最的消息索引
 * @param appName 消息名
 * @return
 */
int LockNotifyModel::appFirstNotifyRow(const QString &appName) const
{
    ListItem group;
    int index = 0;
    int count = m_preNotifyList.size();

    for (int j = 0; j < count; j++) {
        if (m_preNotifyList[j]->appName() == appName)
            return j;
    }

    count = m_notifyGroupList.count();

    for(int i = 0; i < count; i++) {
        group = m_notifyGroupList[i];
        for (int k = 0; k < group.showList.count(); k++) {
            if (group.showList[k]->appName() == appName) {
                return m_preNotifyList.size() + index;
            }
            index++;
        }
    }

    return -1;
}

/**
 * @brief LockNotifyModel::foldAppNotify 折叠应用名appName的所有消息
 * @param appName 应用名
 */
void LockNotifyModel::foldAppNotify(const QString &appName)
{
    Q_UNUSED(appName);
}

/**
 * @brief LockNotifyModel::expandAppNotify  展开应用名appName的所有消息
 * @param appName 应用名
 * @param expandParentRow 应用名appName的第一个消息索引
 * @param parentPosY 应用名appName的第一个消息y轴坐标值
 */
void LockNotifyModel::expandAppNotify(const QString &appName, int expandParentRow, double parentPosY)
{
    bool isSelfInsertBlank = false;
    int groupNotifyCount, groupCount;
    int count = m_notifyGroupList.count();

    for(int i = 0; i < count; i++) {
        ListItem &group = m_notifyGroupList[i];
        if (group.appName == appName) {
            // 处理变间距
            // 自身判断是否需要插入间距
            if (i != 0 && expandParentRow != 0 && group.showList.count() > 0) {
                if (!group.showList[0]->isTitle()) {
                    // 自身变间距
                    isSelfInsertBlank = true;
                    const EntityPtr &entityPtr = group.showList[0];
                    EntityPtr notification = std::make_shared<NotifyEntity>(entityPtr->appName());
                    notification->setIsTitle(true);
                    notification->setState(EnumType::Expand);
                    beginInsertRows(QModelIndex(), expandParentRow , expandParentRow);
                    group.isBlank = true;
                    group.showList.push_front(notification);
                    endInsertRows();
                }
            }
            // 处理下一个应用组变间距
            if (i + 1 < count && m_notifyGroupList[i + 1].showList.count() > 0) {
                if (!m_notifyGroupList[i + 1].showList[0]->isTitle()) {
                    // 下一个插入间距
                    const EntityPtr &entityPtr = m_notifyGroupList[i + 1].showList[0];
                    EntityPtr notification = std::make_shared<NotifyEntity>(entityPtr->appName());
                    notification->setIsTitle(true);
                    notification->setState(entityPtr->state());
                    beginInsertRows(QModelIndex(), expandParentRow + 1, expandParentRow + 1);
                    m_notifyGroupList[i + 1].isBlank = true;
                    m_notifyGroupList[i + 1].showList.push_front(notification);
                    endInsertRows();
                }
            }

            int index = 0;
            int expandIndexOffset = 0;
            double aniOffseY = 0;
            if (isSelfInsertBlank) {
                index = 1;
                // 视图的spaceing + 变间距控件高度
                aniOffseY = 20;
                expandIndexOffset = 1;
            }

            if (!isSelfInsertBlank && group.showList.count() == 2) {
                index = 1;
                expandIndexOffset = 0;
            }

            // 处理折叠
            m_currentExpandAppName = appName;
            m_currentExpandCount = group.hideList.count();
            groupNotifyCount = group.hideList.count() + group.showList.count();
            beginResetModel();
            if (group.showList.count() != 0) {
                group.showList[0]->setState(EnumType::Expand);
                if (index < group.showList.count()) {
                    group.showList[index]->setState(EnumType::Expand);
                    group.showList[index]->setExpandParentRow(expandParentRow + expandIndexOffset);
                    group.showList[index]->setZorder(groupNotifyCount + index);
                }
            }

            groupCount = group.hideList.count();
            group.expand = true;

            for (int j = 0; j < groupCount; j++) {
                group.showList.push_back(group.hideList[j]);
                group.showList.last()->setExpandParentRow(expandParentRow + expandIndexOffset);
                group.showList.last()->setState(EnumType::ExpandChild);
                group.showList.last()->setZorder(groupNotifyCount - j - 1);
                group.showList.last()->setParentPosY(parentPosY + aniOffseY);
            }
            group.hideList.clear();
            endResetModel();
        }
    }
}

/**
 * @brief LockNotifyModel::appName 获取行数为row的应用名
 * @param row 行数
 * @return
 */
QString LockNotifyModel::appName(int row) const
{
    return data(index(row, 0), EnumType::AppName).toString();
}

bool LockNotifyModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    if (EnumType::IsFlicked != role)
        return false;

    int row = index.row();
    // 同一行轻扫不需要复原,行数错误不处理
    if (m_flickedRow == row || row < 0)
        return false;

    bool flicked = value.toBool();
    if (flicked && m_flickedRow != -1 && row != m_flickedRow) {
        // 处理前一个左滑
        EntityPtr flickPtr = entityByRow(m_flickedRow);
        if (flickPtr) {
            flickPtr->setIsFlicked(false);
            QModelIndex flickIndex = this->index(m_flickedRow);
            Q_EMIT dataChanged(flickIndex, flickIndex, m_flickVector);
        }
    }

    EntityPtr entityPtr = entityByRow(row);
    if (!entityPtr)
        return false;

    if (entityPtr->isFlicked() == flicked)
        return false;

    entityPtr->setIsFlicked(flicked);
    if (flicked)
        m_flickedRow = row;
    else
        m_flickedRow = -1;

    Q_EMIT dataChanged(index, index, m_flickVector);

    return true;
}

/**
 * @brief LockNotifyModel::setIsFlicked 设置row上的气泡轻扫状态
 * @param row 行数
 * @param value 是否已经轻扫（左滑）
 */
void LockNotifyModel::setIsFlicked(int row, const QVariant &value)
{
    // 轻扫没有需要复原的，直接返回
    if (m_flickedRow == -1 && !value.toBool())
        return;

    setData(index(row, 0), value, EnumType::IsFlicked);
}

/**
 * @brief LockNotifyModel::state 返回row上的气泡状态（展开、折叠..）
 * @param row 行数
 * @return
 */
int LockNotifyModel::state(int row) const
{
    return data(index(row, 0), EnumType::NotifyState).toInt();
}

/**
 * @brief LockNotifyModel::appFromDesktop 获取系统语言对应的应用名
 * @param desktopName 名字
 * @return
 */
QString LockNotifyModel::appFromDesktop(const QString &desktopName) const
{
    return getDeepinAppName(desktopName);
}

/**
 * @brief LockNotifyModel::appCount 获取通知中应用名为appName的消息总数
 * @param appName 应用名
 * @return
 */
int LockNotifyModel::appCount(const QString &appName) const
{
    ListItem group;
    int count = m_notifyGroupList.count();

    for(int i = 0; i < count; i++) {
        group = m_notifyGroupList[i];
        if (group.appName == appName) {
            return group.showList.size();
        }
    }

    return -1;
}

/**
 * @brief LockNotifyModel::addNotify 添加新消息，更新通知视图
 * @param entity 消息数据
 */
void LockNotifyModel::addNotify(EntityPtr entity)
{
    qInfo() << ".............addNotify";
    // "cancel"表示正在发送蓝牙文件,不需要发送到通知中心
    if (entity->body().contains("%") && entity->actions().contains("cancel")) {
        return;
    }

    beginInsertRows(QModelIndex(), 0, 0);
    m_preNotifyList.push_front(entity);
    endInsertRows();
    qInfo() << ".............Q_EMIT newNotifyAdded";
    Q_EMIT newNotifyAdded();
    Q_EMIT newNotifyChanged();

    if (rowCount(QModelIndex()) == 1)
        Q_EMIT firstNotifyAdded();
}

/**
 * @brief LockNotifyModel::subNotify 数据分组
 */
void LockNotifyModel::subNotify()
{
    int count = m_notifyGroupList.count();
    beginResetModel();

    for(int i = 0; i < count; i++) {
        ListItem &group = m_notifyGroupList[i];
        // 超过规则，折叠
        if (group.hideList.count() + group.showList.count() > MaxUnFoldCount) {
            if (group.showList.count() == 0) {
                group.showList.push_back(group.hideList.first());
                group.hideList.removeLast();
            }
            group.showList.first()->setState(EnumType::Fold);
            group.showList.first()->setZorder(group.hideList.count() + group.showList.count());
        } else {
            for (auto item : group.hideList) {
                group.showList.push_back(item);
            }
            group.hideList.clear();
        }
    }
    endResetModel();
}

/**
 * @brief LockNotifyModel::removeNotify 删除行为row的消息，更新视图
 * @param row 行数
 */
void LockNotifyModel::removeNotify(int row)
{
    if (row >= rowCount(QModelIndex()) || row < 0)
        return;

    removeNotifyFromeDB(row);
    int preCount = m_preNotifyList.count();
    int removeIndex = -1;
    ListItem group;

    if (row < preCount) {
        beginRemoveRows(QModelIndex(), row, row);
        m_preNotifyList.removeAt(row);
        endRemoveRows();
    } else {
        int count = m_notifyGroupList.count();
        int showCount;
        for(int i = 0; i < count; i++) {
            group = m_notifyGroupList[i];
            showCount = group.showList.count();

            for (int k = 0; k < showCount; k++) {
                if (preCount == row) {
                    // 当删除此组最后一个消息时，处理下一组的间距
                    if (showCount < 3 && ((k == 1 && group.showList[0]->isTitle()) || k == 0)) {
                        if (i == 0 && i + 1 < m_notifyGroupList.count() && showCount == 1) {
                            // 下一组不需要间距
                            if (m_notifyGroupList[i + 1].isBlank) {
                                removeBlank(i + 1, row + 1);
                            }
                        } else {
                            if (i - 1 > -1 && i + 1 < m_notifyGroupList.count()) {
                                // 上下都是折叠，下组不需要间距
                                if (!m_notifyGroupList[i - 1].expand && !m_notifyGroupList[i + 1].expand) {
                                    if (m_notifyGroupList[i + 1].isBlank) {
                                        removeBlank(i + 1, row + 1);
                                    }
                                } else {
                                    // 下组需要间距
                                    insertBlank(i + 1, row + 1);
                                }
                            }
                        }
                    }

                    // 当此组有一个变间距时，需要同时删除这个变间距
                    if (m_notifyGroupList[i].showList.count() == 2 && m_notifyGroupList[i].isBlank) {
                        beginRemoveRows(QModelIndex(), row - 1, row);
                        m_notifyGroupList[i].showList.clear();
                        removeIndex = i;
                        endRemoveRows();
                    } else {
                        // 无变间距，直接删除
                        beginRemoveRows(QModelIndex(), row, row);
                        m_notifyGroupList[i].showList.removeAt(k);
                        if (m_notifyGroupList[i].showList.isEmpty())
                            removeIndex = i;
                        endRemoveRows();
                    }

                    preCount++;
                    break;
                }
                preCount++;
            }
        }
    }

    if (rowCount(QModelIndex()) == 0)
        Q_EMIT allNotifyRemoved();
}

/**
 * @brief LockNotifyModel::removeAppGroup 移除与row行消息应用的所有通知
 * @param row 行数
 */
void LockNotifyModel::removeAppGroup(int row)
{
    if (row < -1)
        return;

    int index = 0;
    int count = m_notifyGroupList.count();
    EntityPtr entity = entityByRow(row);
    if (!entity) {
        qCritical() << "entityByRow " << row << " error";
        return;
    }

    QString appName = entity->appName();
    removeAppGroupFromeDB(entity);

    for(int i = 0; i < count; i++) {
        if (m_notifyGroupList[i].appName == appName) {
            break;
        }
        index += m_notifyGroupList[i].showList.count();
    }

    if (index < 0 || index >= rowCount(QModelIndex()))
        return;

    if (m_notifyGroupList[index].showList.count() == 0)
        return;

    // 到达顶部，下一组去间距
    if (index == 0) {
        if (index + 1 < count) {
            if (m_notifyGroupList[index + 1].isBlank) {
                removeBlank(index + 1, 1);
            }
        }
    } else {
        if (m_notifyGroupList[index + 1].expand != m_notifyGroupList[index - 1].expand
                || (m_notifyGroupList[index + 1].expand && m_notifyGroupList[index - 1].expand)) {
            // 下一组需要间距
            if (!m_notifyGroupList[index + 1].isBlank) {
                insertBlank(index + 1, row + 1);
            }
        } else {
            // 下一组不需要间距
            if (m_notifyGroupList[index + 1].isBlank) {
                removeBlank(index + 1, row + 1);
            }
        }
    }

    beginRemoveRows(QModelIndex(), row, row);
    m_notifyGroupList.removeAt(index);
    endRemoveRows();

    if (rowCount(QModelIndex()) == 0)
        Q_EMIT allNotifyRemoved();
}

/**
 * @brief LockNotifyModel::removeAllNotify 清除所有通知
 */
void LockNotifyModel::removeAllNotify()
{
    beginResetModel();
    m_preNotifyList.clear();
    m_notifyGroupList.clear();
    endResetModel();

    removeAllFromeDB();

    Q_EMIT allNotifyRemoved();
}

/**
 * @brief LockNotifyModel::refreshFold 刷新消息折叠
 */
void LockNotifyModel::refreshFold()
{
    int oldCount = m_notifyGroupList.count();

    beginResetModel();
    // 去掉间距,显示消息转移到隐藏,按照时间排序,使showlist中第一个消息时间最早
    for (int i = 0; i < oldCount; i++) {
        ListItem &group = m_notifyGroupList[i];
        for (int j = group.showList.count() - 1; j > -1; j--) {
            if (!group.showList[j]->isTitle())
                group.hideList.push_front(group.showList[j]);

            group.isBlank = false;
            group.expand = true;
        }

        group.showList.clear();
    }

    int preCount = m_preNotifyList.count();
    for (int i = preCount - 1; i > -1 ;i--) {
        addAppData(m_preNotifyList[i]);
    }

    m_preNotifyList.clear();
    int count = m_notifyGroupList.count();

    // 折叠
    for(int i = 0; i < count; i++) {
        ListItem &group = m_notifyGroupList[i];

        if (group.hideList.count() + group.showList.count() > MaxUnFoldCount) {
            if (group.showList.count() == 0) {
                group.showList.push_back(group.hideList.first());
                group.hideList.removeFirst();
            }
            group.expand = false;
            group.showList.first()->setState(EnumType::Fold);
            group.showList.first()->setZorder(group.hideList.count() + group.showList.count());

            int hideCount =  group.hideList.count();

            for (int j = 0; j < hideCount; j++) {
                m_notifyGroupList[i].hideList[j]->setState(EnumType::Hide);
            }
        } else {
            for (auto item : group.hideList) {
                group.showList.push_back(item);
            }
            group.hideList.clear();
        }

        qSort(group.hideList.begin(), group.hideList.end(), [ = ](const EntityPtr& ptr1, const EntityPtr& ptr2){
            return ptr1->ctime().toLongLong() > ptr2->ctime().toLongLong();
        });
    }

    // 应用组排序
    qSort(m_notifyGroupList.begin(), m_notifyGroupList.end(), [ = ](const ListItem& list1, const ListItem& list2){
        return list1.lastTimeStamp.toLongLong() > list2.lastTimeStamp.toLongLong();
    });

    // 初始化数据时，添加间距设置
    for(int j = 0; j < count; j++) {
        if (j != 0) {
            if (m_notifyGroupList[j].showList.count() == 0 || m_notifyGroupList[j - 1].showList.count() == 0)
                continue;

            // 判断组与组之间是否满足变间距规则，满足则插入空白间距
            if ((m_notifyGroupList[j].showList[0]->state() != EnumType::Fold
                 && m_notifyGroupList[j - 1].showList[0]->state() != EnumType::Fold)
                    || (m_notifyGroupList[j].showList[0]->state() != EnumType::Fold
                        && m_notifyGroupList[j - 1].showList[0]->state() == EnumType::Fold)
                    || (m_notifyGroupList[j].showList[0]->state() == EnumType::Fold
                        && m_notifyGroupList[j - 1].showList[0]->state() != EnumType::Fold)) {
                const EntityPtr &entityPtr = m_notifyGroupList[j].showList[0];
                EntityPtr notification = std::make_shared<NotifyEntity>(entityPtr->appName());
                notification->setIsTitle(true);
                notification->setState(entityPtr->state());
                m_notifyGroupList[j].isBlank = true;
                m_notifyGroupList[j].showList.push_front(notification);
            }
        }
    }

    endResetModel();
}

/**
 * @brief LockNotifyModel::handleScreenFullBlack 黑屏处理
 * @param msg
 */
void LockNotifyModel::handleScreenFullBlack(QDBusMessage msg)
{
    QList<QVariant> outArgs = msg.arguments();
    if (outArgs.isEmpty())
        return;

    if (outArgs.at(0).toInt() == 7)
        refreshFold();
}

/**
 * @brief LockNotifyModel::breakLockAuthConnect 打断解锁的信号连接
 */
void LockNotifyModel::breakLockAuthConnect()
{
    disconnect(m_readAuthConnection);
    disconnect(m_invokeAuthConnection);
}

/**
 * @brief LockNotifyModel::isTimeOutDelete 判断超时是否删除
 * @return
 */
bool LockNotifyModel::isTimeOutDelete() const
{
    return m_gsettings->get("istimeoutdelete").toBool();
}

/**
 * @brief LockNotifyModel::readNotify 阅读消息
 * @param appName 应用名字
 * @param row 行数
 */
void LockNotifyModel::readNotify(const QString &appName, int row)
{
    resetFlickable();

//    auto shell_manager = DueShellManager::instance();
//    shell_manager->lockAuthenticating();
//    if (!shell_manager->isAuthenticating()) {
//        EntityPtr entity = entityByRow(row);
//        removeNotify(row);
//        shell_manager->setLockVisible(false);
//        openDesktopApp(entity);

//        return;
//    }

    disconnect(m_readAuthConnection);
//    m_readAuthConnection = connect(shell_manager, &DueShellManager::authStatusChanged, this, [ = ](bool result){
//        if (result) {
//            EntityPtr entity = entityByRow(row);
//            removeNotify(row);
//            shell_manager->setLockVisible(false);
//            openDesktopApp(entity);
//            breakLockAuthConnect();
//        }
//    });
}

/**
 * @brief LockNotifyModel::notifyActionInvoke 消息按钮点击处理
 * @param id 按钮id
 * @param hints 提示
 * @param row 行数
 */
void LockNotifyModel::notifyActionInvoke(const QString &actionid, const QVariantMap &hints, int row)
{
    EntityPtr entity = entityByRow(row);
    if (!entity)
        return;

//    auto shell_manager = DueShellManager::instance();
//    shell_manager->lockAuthenticating();
//    if (!shell_manager->isAuthenticating()) {
//        removeNotify(row);
//        shell_manager->setLockVisible(false);
//        actionInvoke(entity, actionid, hints);

//        return;
//    }

    disconnect(m_invokeAuthConnection);
//    m_invokeAuthConnection = connect(shell_manager, &DueShellManager::authStatusChanged, this, [ = ](bool result){
//        if (result) {
//            removeNotify(row);
//            shell_manager->setLockVisible(false);
//            actionInvoke(entity, actionid, hints);
//            breakLockAuthConnect();
//        }
//    });
}

/**
 * @brief LockNotifyModel::removeTimeOutNotify 移除超时通知
 */
void LockNotifyModel::removeTimeOutNotify()
{

}

QHash<int, QByteArray> LockNotifyModel::roleNames() const
{
   return m_roleNames;
}

/**
 * @brief LockNotifyModel::addAppData 向通知添加一条通知消息,注意排序,从上面加
 * @param entity 消息数据
 */
void LockNotifyModel::addAppData(EntityPtr entity)
{
    bool isNewApp = true;
    int count = m_notifyGroupList.count();
    const QString time = entity->ctime();
    const QString appName = entity->appName();

    for(int i = 0; i < count; i++) {
        ListItem &group = m_notifyGroupList[i];
        if (group.appName == appName) {
            isNewApp = false;

            if (group.lastTimeStamp.toLongLong() < time.toLongLong()) {
                if (!group.showList.isEmpty()) {
                    group.hideList.push_front(group.showList.at(0));
                    group.showList.clear();
                }

                group.showList.append(entity);
                group.lastTimeStamp = time;
            } else {
                entity->setState(EnumType::Hide);
                group.hideList.push_front(entity);
            }
        }
        if (i != 0)
            m_notifyGroupList.move(i, 0);
    }

    if (isNewApp) {
        ListItem appGroup;
        appGroup.appName = appName;
        appGroup.lastTimeStamp = time;
        appGroup.showList.push_front(entity);
        m_notifyGroupList.append(appGroup);
    }
}

/**
 * @brief LockNotifyModel::entityByRow 根据row获取通知消息数据
 * @param row 行数
 * @return 消息数据
 */
EntityPtr LockNotifyModel::entityByRow(int row) const
{
    if (row > rowCount(QModelIndex()) - 1 || row < 0)
        return nullptr;

    int index = m_preNotifyList.size();

    if (row < index)
        return m_preNotifyList[row];

    int showCount;
    int count = m_notifyGroupList.count();

    for (int i = 0; i < count; i++) {
        const auto &item = m_notifyGroupList[i];
        showCount = item.showList.count();
        for (int j = 0; j < showCount; j++) {
            if (index == row) {
                EntityPtr ptr = item.showList.at(j);
                return item.showList.at(j);
            }
            index++;
        }
    }

    return nullptr;
}

/**
 * @brief LockNotifyModel::checkTimeOut 检查消息是否超时
 * @param ptr 消息数据
 * @param sec 时间差
 * @return 是否超时
 */
bool LockNotifyModel::checkTimeOut(EntityPtr ptr, int sec)
{
    QDateTime t = QDateTime::fromMSecsSinceEpoch(ptr->ctime().toLongLong());
    return t.secsTo(QDateTime::currentDateTime()) > sec;
}

/**
 * @brief LockNotifyModel::insertBlank 插入空白间距
 * @param index 数组索引
 * @param insertRow 插入行
 */
void LockNotifyModel::insertBlank(int index, int insertRow)
{
    const EntityPtr &entityPtr = m_notifyGroupList[index].showList[0];
    EntityPtr notification = std::make_shared<NotifyEntity>(entityPtr->appName());
    notification->setIsTitle(true);
    notification->setState(entityPtr->state());
    beginInsertRows(QModelIndex(), insertRow, insertRow);
    m_notifyGroupList[index].isBlank = true;
    m_notifyGroupList[index].showList.push_front(notification);
    endInsertRows();
}

/**
 * @brief LockNotifyModel::removeBlank 删除空白间距
 * @param index 数组索引
 * @param removeRow 删除行
 */
void LockNotifyModel::removeBlank(int index, int removeRow)
{
    beginRemoveRows(QModelIndex(), removeRow, removeRow);
    m_notifyGroupList[index].isBlank = false;
    m_notifyGroupList[index].showList.removeFirst();
    endRemoveRows();
}

void LockNotifyModel::removeNotifyFromeDB(int row)
{
    EntityPtr entity = entityByRow(row);
    if (!entity)
        return;

    Q_EMIT requstRemoveNotifyFromeDB(entity->appName(), QString::number(entity->id()));
}

void LockNotifyModel::removeAppGroupFromeDB(EntityPtr entity)
{
    const QString appName = entity->appName();

    // 量小时，先过滤判断该应用是否全部折叠，如果全部折叠直接删数据表
    if (m_preNotifyList.count() < 5) {
        bool searchResult = false;
        for (auto item : m_preNotifyList) {
            if (item->appName() == appName) {
                searchResult = true;
                break;
            }
        }

        if (!searchResult) {
            Q_EMIT requstRemoveNotifyTableFromeDB(appName);
            return;
        }
    }

    for (auto listItem : m_notifyGroupList) {
        if (appName == listItem.appName) {
            for (auto showEntity : listItem.showList) {
                Q_EMIT requstRemoveNotifyFromeDB(showEntity->appName(), QString::number(showEntity->id()));
            }
            for (auto hideEntity : listItem.hideList) {
                Q_EMIT requstRemoveNotifyFromeDB(hideEntity->appName(), QString::number(hideEntity->id()));
            }
            break;
        }
    }
}

void LockNotifyModel::resetFlickable()
{
    if (m_flickedRow  < 0)
        return;

    EntityPtr entityPtr = entityByRow(m_flickedRow);
    if (!entityPtr)
        return;

    if (!entityPtr->isFlicked())
        return;

    entityPtr->setIsFlicked(false);

    Q_EMIT dataChanged(index(m_flickedRow, 0), index(m_flickedRow, 0), m_flickVector);
    m_flickedRow = -1;
}

