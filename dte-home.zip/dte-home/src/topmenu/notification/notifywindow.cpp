/*
 * Copyright (C) 2020 ~ 2021 Uniontech Software Technology Co.,Ltd.
 *
 * Author:     xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * Maintainer: xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "notifywindow.h"
#include "public_func.h"
//#include "dueshellmanager.h"
#include "notifymanager.h"

#include <QGuiApplication>
#include <QScreen>
#include <QParallelAnimationGroup>
#include <QPropertyAnimation>

//#include <com_deepin_wm.h>

//using WindowManagerInter = com::deepin::wm;

/**
 * @brief NotifyWindow::NotifyWindow 消息横幅和osd主窗口，
 * @param parent
 * @param orientation 窗口的方向
 * @param alignments 窗口对齐方式
 */
NotifyWindow::NotifyWindow(QWindow *parent)
    : QQuickView(parent)
    , m_AnimationType(AnimationType::Hide)
    , m_aniGroup(new QParallelAnimationGroup(this))
    , m_posAnimation(new QPropertyAnimation(this, "y"))
    , m_opacityAnimation(new QPropertyAnimation(this, "opacity"))
    , m_animatinTime(300)
    , m_isOpenApp(false)
    , m_isPushInNotifyCenter(true)
{
    init();
    initConnect();
}

void NotifyWindow::setOrientation(EnumType::Orientation orientation)
{
    if (m_orientation != orientation)
        m_orientation = orientation;
}

void NotifyWindow::setAlignment(EnumType::Alignment alignment)
{
    if (m_alignments != alignment)
        m_alignments = alignment;
}

EntityPtr NotifyWindow::entityPtr() const
{
    return m_entity;
}

void NotifyWindow::setEntityPtr(const EntityPtr &entity)
{
    m_entity = entity;
}

void NotifyWindow::setIsPushInNotifyCenter(bool isPush)
{
    if (isPush == m_isPushInNotifyCenter)
        return;

    m_isPushInNotifyCenter = isPush;
}

/**
 * @brief NotifyWindow::transAnimation 执行动画
 * @param type 动画类型（显示、消失）
 */
void NotifyWindow::transAnimation(AnimationType type)
{
    m_AnimationType = type;
    if (m_aniGroup->state() == QAbstractAnimation::Running)
        m_aniGroup->stop();

    m_posAnimation->setDuration(m_animatinTime);
    m_opacityAnimation->setDuration(m_animatinTime);

    m_opacityAnimation->setStartValue(1);
    m_opacityAnimation->setEndValue(0);

    if (m_orientation == EnumType::Horizontal) {
        if (EnumType::Top == m_alignments) {
            m_posAnimation->setEndValue(0);
        } else {
            m_posAnimation->setEndValue(QGuiApplication::primaryScreen()->size().height());
        }
        m_posAnimation->setStartValue(y());
    } else {
        m_posAnimation->setPropertyName("x");

        if (EnumType::Left == m_alignments) {
            m_posAnimation->setEndValue(0);
        } else {
            m_posAnimation->setEndValue(QGuiApplication::primaryScreen()->size().width() - width());
        }
        m_posAnimation->setStartValue(x());
    }
    m_aniGroup->addAnimation(m_posAnimation);
    m_aniGroup->addAnimation(m_opacityAnimation);
    if (AnimationType::Hide != type)
        m_aniGroup->setDirection(QAbstractAnimation::Backward);
    else
        m_aniGroup->setDirection(QAbstractAnimation::Forward);

    m_aniGroup->start();
}

/**
 * @brief NotifyWindow::openApp 打开APP应用
 */
void NotifyWindow::openApp()
{
    m_isOpenApp = true;
    const QVariantMap hints = m_entity->hints();
    if (!hints.contains(DDESESSIONCC::NotifyClickDefineKey)) {
        closeMultiTaskingView();
        // 截图定制，不需要发送消息
        openDesktopApp(m_entity, false);
        return;
    }

    closeMultiTaskingView();
    actionInvoke(m_entity ,DDESESSIONCC::NotifyClickDefineKey, m_entity->hints());

    if (m_aniGroup->state() == QAbstractAnimation::Running)
        return;

    transAnimation();
}

void NotifyWindow::bannerActionInvoke(const QString &id)
{
    closeMultiTaskingView();
    actionInvoke(m_entity, id, m_entity->hints());
    m_isPushInNotifyCenter = false;

    if (m_aniGroup->state() == QAbstractAnimation::Running)
        return;

    transAnimation();
}

void NotifyWindow::handleAnimationFinished()
{
    if (AnimationType::Show == m_AnimationType)
        return;

    Q_EMIT hideAnimationFinished();
    NotifyManager::ClosedReason reason = m_isOpenApp ? NotifyManager::Dismissed : NotifyManager::Closed;
//    Q_EMIT DueShellManager::instance()->notifyClosed(m_entity->id(), reason);

    if (m_isOpenApp)
        m_isOpenApp = false;
}

void NotifyWindow::init()
{
//    DQuickWindowAttached *attach = attached();
//    attach->setWmWindowTypes(DTK_GUI_NAMESPACE::DWindowManagerHelper::NotificationType);

//    setColor("transparent");
//    attach->setEnableBlurWindow(true);
//    attach->setEnableSystemMove(false);
//    attach->setEnableSystemResize(false);
}

void NotifyWindow::initConnect()
{
    connect(m_aniGroup, &QParallelAnimationGroup::finished, this, &NotifyWindow::handleAnimationFinished);
}

void NotifyWindow::closeMultiTaskingView()
{
//    WindowManagerInter inter("com.deepin.wm", "/com/deepin/wm", QDBusConnection::sessionBus());
//    if (!inter.GetMultiTaskingStatus())
//        return;

//    inter.ShowWorkspace();
}
