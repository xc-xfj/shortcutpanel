/*
 * Copyright (C) 2020 ~ 2021 Uniontech Software Technology Co.,Ltd.
 *
 * Author:     xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * Maintainer: xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "notifymanager.h"
#include "persistence.h"
//#include "pulldownmanager.h"
//#include "screenimageprovider.h"
//#include "sessionbasemodel.h"
//#include "shelladaptor.h"
//#include "dbuslockagent.h"
//#include "lockadaptor.h"
//#include "dbusshutdownagent.h"
//#include "shutdownadaptor.h"
#include "locknotifymodel.h"
#include "notifycentermodel.h"
#include "notifysettings.h"
#include "desktopservices.h"
#include "notifywindow.h"
//#include "shellinterface.h"
//#include "dueshellmanager.h"

#include <DDBusSender>

#include <QQmlEngine>
#include <QDBusConnection>
#include <QQmlContext>
#include <QTimer>
#include <QDebug>
#include <QScreen>
#include <QGuiApplication>
#include <QObject>
#include <QQuickItem>
#include <QDBusContext>
#include <QDBusVariant>
#include <QDBusInterface>
#include <QJsonDocument>
#include <QDBusConnectionInterface>

const int OutTime = 2000;   // 默认消失时间

NotifyManager::NotifyManager(QObject *parent, QQmlEngine *engine)
    : QObject(parent)
    , m_persistence(new Persistence)
    , m_notifyCenterModel(new NotifyCenterModel(parent, m_persistence))
    , m_lockNotifyModel(new LockNotifyModel(parent))
//    , m_shellInter(new ShellInterface(DDESESSIONCC::SHELL_DBUS_NAME
//                                      , DDESESSIONCC::SHELL_DBUS_PATH
//                                      , QDBusConnection::sessionBus(), this))
    , m_notifySettings(new NotifySettings(this))
//    , m_sessionPowerInter(new QDBusInterface("com.deepin.daemon.Power"
//                                        , "/com/deepin/daemon/Power"
//                                        , "com.deepin.daemon.Power"
//                                        , QDBusConnection::sessionBus(), this))
{
    registerAsService();
    engine->rootContext()->setContextProperty("notifyCenterModel", m_notifyCenterModel);
    engine->rootContext()->setContextProperty("lockNotifyModel", m_lockNotifyModel);

    qInfo() << ".......................m_notifyCenterModel" << m_notifyCenterModel << m_lockNotifyModel;
    initConnect();
    updateSysNotifyProperty();
}

NotifyManager::~NotifyManager()
{

}

/**
 * @brief NotifyManager::CloseNotification 根据Notify函数处理后返回的ID来关闭气泡
 */
void NotifyManager::CloseNotification(uint id)
{
    if (m_bannerList.isEmpty())
        return;

    if (id == m_bannerList[0]->entityPtr()->id()) {
        m_bannerList[0]->setIsPushInNotifyCenter(false);
        m_bannerList[0]->transAnimation(AnimationType::Hide);
    }
}

/**
 * @brief NotifyManager::GetCapabilities 返回描述服务器实现的功能字符串
 * @return 通知服务描述字符串
 */
QStringList NotifyManager::GetCapabilities()
{
    static const QStringList result = {"action-icons", "actions", "body", "body-hyperlinks", "body-markup"};
    return result;
}

/**
 * @brief NotifyManager::GetServerInformation 获取服务信息
 * @param name
 * @param vender
 * @param version
 * @return
 */
QString NotifyManager::GetServerInformation(QString &name, QString &vender, QString &version)
{
    name = QString("DeepinNotifications");
    vender = QString("Deepin");
    version = QString("2.0");

    return QString("1.2");
}

/**
 * @brief NotifyManager::Notify 添加通知，返回一个根据通知内容生成的通知ID
 * @param appName App名称
 * @param replacesId ID
 * @param appIcon App图标名称
 * @param summary 通知信息概要
 * @param body 通知信息主体
 * @param actions 按钮信息
 * @param hints 提示信息
 * @param expireTimeout 多长时间超时过期,值为-1时不会超时
 * @return 返回一个处理后的replacesId
 */
uint NotifyManager::Notify(const QString &appName, uint replacesId,
                           const QString &appIcon, const QString &summary,
                           const QString &body, const QStringList &actions,
                           const QVariantMap hints, int expireTimeout)
{
    qInfo() << "-----------------------------Notify";
    QString strBody = body;
    strBody.replace(QLatin1String("\\\\"), QLatin1String("\\"), Qt::CaseInsensitive);

    EntityPtr notification = std::make_shared<NotifyEntity>(appName, QString(), appIcon,
                                                            summary, strBody, actions, hints,
                                                            QString::number(QDateTime::currentMSecsSinceEpoch()),
                                                            QString::number(replacesId),
                                                            QString::number(expireTimeout));
    AppNotifyProperty notifyProperty = appNotifyProperty(notification->appName());

    if ((notifyProperty.isNotificationSound && notifyProperty.isAllowNotify && !isDoNotDisturb())
            || notification->appName().contains("dde-control-center")) {
        QString action;
        //接收蓝牙文件时，只在发送完成后才有提示音,"cancel"表示正在发送文件
        if (actions.contains("cancel")) {
            if (hints.contains("x-deepin-action-_view")) {
                action = hints["x-deepin-action-_view"].toString();
                if (action.contains("xdg-open"))
                    DesktopServices::playSystemSoundEffect(DesktopServices::SSE_Notifications);
            }
        } else {
            // 系统应用有声音提醒
            if (notification->appName().contains("dde-control-center")) {
                DesktopServices::playSystemSoundEffect(DesktopServices::SSE_Notifications);
            } else {
                // 非系统应用在锁屏时勿扰开启情况下锁屏无消息提醒
/*                if (DueShellManager::instance()->lockVisible()) {
                    if (!(m_sysNotifyProperty.isScreenLocked && m_sysNotifyProperty.isDoNotDisturb))
                        DesktopServices::playSystemSoundEffect(DesktopServices::SSE_Notifications);
                } else*/ {
                    DesktopServices::playSystemSoundEffect(DesktopServices::SSE_Notifications);
                }
            }
        }
    }

    if (!notifyProperty.isAllowNotify)
        return 0;

    notification->setShowPreview(notifyProperty.isShowNotifyPreview);
    notification->setShowInNotifyCenter(notifyProperty.isShowInNotifyCenter);

    if (!isDoNotDisturb() || notification->appName().contains("dde-control-center")) {
 /*       if (DueShellManager::instance()->shutdownVisible()) {
            if (!isInTransit(notification) && notifyProperty.isShowInNotifyCenter)
                addInNotifyCenter(notification);
        } else */{
/*            if (!DueShellManager::instance()->lockVisible()) {
                // 横幅显示文件传输特殊处理
                if (!isInTransit(notification))
                    m_persistence->addEntity(notification);

                pushBanner(notification);
            } else*/ {
                if (notifyProperty.isLockShowNotify && !(m_sysNotifyProperty.isScreenLocked && m_sysNotifyProperty.isDoNotDisturb)) {
                    if (!isInTransit(notification))
                        addNotifyInLock(notification);
                } else {
                    if (!isInTransit(notification) && notifyProperty.isShowInNotifyCenter)
                        addInNotifyCenter(notification);
                }
            }
        }
    } else {
/*        if (DueShellManager::instance()->shutdownVisible()) {
            if (!isInTransit(notification) && notifyProperty.isShowInNotifyCenter)
                addInNotifyCenter(notification);
        } else */{
//            if (!DueShellManager::instance()->lockVisible()) {
            if (!false) {
                if (!m_sysNotifyProperty.isTimeSlot) {
                    // 非勿扰时间内或只在锁屏勿扰显示横幅
                    if (!isInTransit(notification)) {
                        m_persistence->addEntity(notification);
                        qInfo() << ".........................";
                    }

                    pushBanner(notification);
                        qInfo() << "....................." << "end pushBanner";
                } else {
                    if (!isInTransit(notification) && notifyProperty.isShowInNotifyCenter) {
                        addInNotifyCenter(notification);
                    }
                }
            } else {
                // 锁屏勿扰时判断锁屏勿扰是否勾选
                if (m_sysNotifyProperty.isTimeSlot || m_sysNotifyProperty.isScreenLocked) {
                    if (!isInTransit(notification) && notifyProperty.isShowInNotifyCenter)
                        addInNotifyCenter(notification);
                } else {
                    if (!isInTransit(notification))
                        addNotifyInLock(notification);
                }
            }
        }
    }

    return replacesId == 0 ? notification->id() : replacesId;

    qInfo() << "....................." << "end notify";
}

/**
 * @brief NotifyManager::GetAllRecords 返回所有通知的记录
 * @return 返回一个json格式的字符串
 */
QString NotifyManager::GetAllRecords()
{
    return "";
}

/**
 * @brief NotifyManager::GetRecordById 根据ID查询通知记录
 * @param id
 * @return 返回一个json格式的字符串
 */
QString NotifyManager::GetRecordById(const QString &id)
{
    Q_UNUSED(id);
    return "";
}

/**
 * @brief NotifyManager::GetRecordsFromId 分页查询
 * @param rowCount 数量
 * @param offsetId 起始id
 * @return 返回id在[offsetId + 1， offsetId + 1 + rowCount ]区间内消息json格式字符串
 */
QString NotifyManager::GetRecordsFromId(int rowCount, const QString &offsetId)
{
    Q_UNUSED(rowCount);
    Q_UNUSED(offsetId);
    return "";
}

/**
 * @brief NotifyManager::RemoveRecord 根据ID删除通知记录
 * @param id
 */
void NotifyManager::RemoveRecord(const QString &id)
{
    Q_UNUSED(id);
}

/**
 * @brief NotifyManager::ClearRecords 删除所有通知记录
 */
void NotifyManager::ClearRecords()
{

}

/**
 * @brief NotifyManager::Toggle 控制通知中心的显示和隐藏,废弃，平板不用
 */
void NotifyManager::Toggle()
{
}

/**
 * @brief NotifyManager::recordCount 返回通知中心中通知的数量
 * @return 消息总数
 */
uint NotifyManager::recordCount()
{
    return 0;
}

/**
 * @brief NotifyManager::GetAppList 返回app列表
 * @return
 */
QStringList NotifyManager::GetAppList()
{
    return m_notifySettings->getAppLists();
}

QDBusVariant NotifyManager::GetAppInfo(const QString id, uint item)
{
    return QDBusVariant(m_notifySettings->getAppSetting(id, static_cast<NotifySettings::AppConfigurationItem>(item)));
}

QDBusVariant NotifyManager::GetSystemInfo(uint item)
{
    return QDBusVariant(m_notifySettings->getSystemSetting(static_cast<NotifySettings::SystemConfigurationItem>(item)));
}

void NotifyManager::SetAppInfo(const QString id, uint item, const QDBusVariant var)
{
    m_notifySettings->setAppSetting(id, static_cast<NotifySettings::AppConfigurationItem>(item), var.variant());
}

void NotifyManager::SetSystemInfo(uint item, const QDBusVariant var)
{
    m_notifySettings->setSystemSetting(static_cast<NotifySettings::SystemConfigurationItem>(item), var.variant());
    updateSysNotifyProperty();
    Q_EMIT systemSettingChanged(m_notifySettings->getSystemSetings());
}

/**
 * @brief NotifyManager::getAllSetting 获取所有通知配置
 * @return
 */
QString NotifyManager::getAllSetting()
{
    return m_notifySettings->getAllSetings();
}

/**
 * @brief NotifyManager::setAllSetting 设置所有通知配置
 * @param settings 配置信息
 */
void NotifyManager::setAllSetting(const QString settings)
{
    m_notifySettings->setAllSetting(settings);
}

/**
 * @brief NotifyManager::getAppSetting 获取app对应的通知配置
 * @param appName app名
 * @return 配置字符串
 */
QString NotifyManager::getAppSetting(QString appName)
{
    return m_notifySettings->getAppSettings(appName);
}

/**
 * @brief NotifyManager::setAppSetting 设置app通知配置
 * @param settings 配置信息
 */
void NotifyManager::setAppSetting(const QString settings)
{
    QJsonObject currentObj = QJsonDocument::fromJson(settings.toUtf8()).object();
    m_notifySettings->setAppSetting(settings);
    Q_EMIT appSettingChanged(currentObj.begin().key());
}

/**
 * @brief NotifyManager::getSystemSetting 获取系统通知配置
 * @return 配置信息
 */
QString NotifyManager::getSystemSetting()
{
    return m_notifySettings->getSystemSetings();
}

/**
 * @brief NotifyManager::setSystemSetting 设置系统通知配置
 * @param settings 配置信息
 */
void NotifyManager::setSystemSetting(QString settings)
{
    m_notifySettings->setSystemSetting(settings);
    updateSysNotifyProperty();
    Q_EMIT systemSettingChanged(m_notifySettings->getSystemSetings());
}

AppNotifyProperty NotifyManager::appNotifyProperty(const QString &appName)
{
    QJsonObject currentObj = QJsonDocument::fromJson(getAppSetting(appName).toUtf8()).object();
    QJsonObject currentSettingsObj = currentObj.begin().value().toObject();

    AppNotifyProperty appNotifyProperty;
    if (currentSettingsObj.contains(AllowNotifyStr)) {
        appNotifyProperty.isAllowNotify = currentSettingsObj[AllowNotifyStr].toBool();
    } else {
        appNotifyProperty.isAllowNotify = DEFAULT_ALLOW_NOTIFY;
    }

    if (currentSettingsObj.contains(ShowInNotifyCenterStr)) {
        appNotifyProperty.isShowInNotifyCenter = currentSettingsObj[ShowInNotifyCenterStr].toBool();
    } else {
        appNotifyProperty.isShowInNotifyCenter = DEFAULT_ONLY_IN_NOTIFY;
    }

    if (currentSettingsObj.contains(LockShowNotifyStr)) {
        appNotifyProperty.isLockShowNotify = currentSettingsObj[LockShowNotifyStr].toBool();
    } else {
        appNotifyProperty.isLockShowNotify = DEFAULT_LOCK_SHOW_NOTIFY;
    }

    if (currentSettingsObj.contains(NotificationSoundStr)) {
        appNotifyProperty.isNotificationSound = currentSettingsObj[NotificationSoundStr].toBool();
    } else {
        appNotifyProperty.isNotificationSound = DEFAULT_NOTIFY_SOUND;
    }

    if (currentSettingsObj.contains(ShowNotifyPreviewStr)) {
        appNotifyProperty.isShowNotifyPreview = currentSettingsObj[ShowNotifyPreviewStr].toBool();
    } else {
        appNotifyProperty.isShowNotifyPreview = DEFAULT_SHOW_NOTIFY_PREVIEW;
    }

    return appNotifyProperty;
}

/**
 * @brief NotifyManager::registerAsService 注册服务
 */
void NotifyManager::registerAsService()
{
    QDBusConnection connection = QDBusConnection::sessionBus();
    connection.interface()->registerService(DDESESSIONCC::NOTIFICATIONS_DBUS_SERVICE,
                                            QDBusConnectionInterface::ReplaceExistingService,
                                            QDBusConnectionInterface::AllowReplacement);
     if (!connection.registerObject(DDESESSIONCC::NOTIFICATIONS_DBUS_PATH, this)) {
         connection.unregisterObject(DDESESSIONCC::NOTIFICATIONS_DBUS_PATH);
         if (!connection.registerObject(DDESESSIONCC::NOTIFICATIONS_DBUS_PATH, this)) {
              qInfo() << DDESESSIONCC::NOTIFICATIONS_DBUS_PATH << "register failed";
         }
     }

    if (!connection.interface()->registerService(DDESESSIONCC::DDE_NOTIFY_DBUS_SERVER))
        qWarning() << "Check if the notify service exists, palease try to killall dde-osd!";

    connection.registerObject(DDESESSIONCC::DDE_NOTIFY_DBUS_PATH, this);
}

/**
 * @brief NotifyManager::isDoNotDisturb 系统是否是勿扰模式
 * @return
 */
bool NotifyManager::isDoNotDisturb()
{
    if (m_sysNotifyProperty.isDoNotDisturb) {
        bool isTimeMeet = false;

        QTime currentTime = QTime::fromString(QDateTime::currentDateTime().toString("hh:mm"));
        QTime startTime = QTime::fromString(m_sysNotifyProperty.StartTime);
        QTime endTime = QTime::fromString(m_sysNotifyProperty.EndTime);
        //判断当前时间是否再时间段内
        if (startTime < endTime) {
            if (startTime <= currentTime && endTime >= currentTime) {
                isTimeMeet = true;
            } else {
                isTimeMeet = false;
            }
        } else if (startTime > endTime) {
            if (startTime <= currentTime || endTime >= currentTime) {
                isTimeMeet = true;
            } else {
                isTimeMeet = false;
            }
        } else {
            isTimeMeet = true;
        }

        if (!m_sysNotifyProperty.isTimeSlot)
            return false;

        //时间段满足
        if (isTimeMeet && m_sysNotifyProperty.isTimeSlot) {
            return true;
        }

        return false;
    } else {
        return false;
    }
}

/**
 * @brief NotifyManager::updateSysNotifyProperty 更新系统通知设置的属性
 */
void NotifyManager::updateSysNotifyProperty()
{
        qInfo() << ".............updateSysNotifyProperty start";
    QJsonObject currentObj = QJsonDocument::fromJson(getSystemSetting().toUtf8()).object();
    QJsonObject currentSettingsObj = currentObj.begin().value().toObject();
    if (currentSettingsObj.contains(DoNotDisturbStr)) {
        m_sysNotifyProperty.isDoNotDisturb = currentSettingsObj[DoNotDisturbStr].toBool();
    } else {
        m_sysNotifyProperty.isDoNotDisturb = DEFAULT_DO_NOT_DISTURB;
    }

    if (currentSettingsObj.contains(TimeSlotStr)) {
        m_sysNotifyProperty.isTimeSlot = currentSettingsObj[TimeSlotStr].toBool();
    } else {
        m_sysNotifyProperty.isTimeSlot = DEFAULT_TIME_SLOT;
    }

    if (currentSettingsObj.contains(StartTimeStr)) {
        m_sysNotifyProperty.StartTime = currentSettingsObj[StartTimeStr].toString();
    } else {
        m_sysNotifyProperty.StartTime = DefaultStartTime;
    }

    if (currentSettingsObj.contains(EndTimeStr)) {
        m_sysNotifyProperty.EndTime = currentSettingsObj[EndTimeStr].toString();
    } else {
        m_sysNotifyProperty.EndTime = DefaultEndTime;
    }

    if (currentSettingsObj.contains(AppsInFullscreenStr)) {
        m_sysNotifyProperty.isAppsInFullscreen = currentSettingsObj[AppsInFullscreenStr].toBool();
    } else {
        m_sysNotifyProperty.isAppsInFullscreen = DEFAULT_APP_IN_FULLSCREEN;
    }

    if (currentSettingsObj.contains(AppsInFullscreenStr)) {
        m_sysNotifyProperty.isAppsInFullscreen = currentSettingsObj[AppsInFullscreenStr].toBool();
    } else {
        m_sysNotifyProperty.isAppsInFullscreen = DEFAULT_APP_IN_FULLSCREEN;
    }

    if (currentSettingsObj.contains(ConnectedProjectorStr)) {
        m_sysNotifyProperty.isConnectedProjector = currentSettingsObj[ConnectedProjectorStr].toBool();
    } else {
        m_sysNotifyProperty.isConnectedProjector = DEFAULT_CONNECTED_PROJECTOR;
    }

    if (currentSettingsObj.contains(ScreenLockedStr)) {
        m_sysNotifyProperty.isScreenLocked = currentSettingsObj[ScreenLockedStr].toBool();
    } else {
        m_sysNotifyProperty.isScreenLocked = DEFAULT_SCREEN_LOCKED;
    }

    if (currentSettingsObj.contains(ShowIconOnDockStr)) {
        m_sysNotifyProperty.isShowIconOnDock = currentSettingsObj[ShowIconOnDockStr].toBool();
    } else {
        m_sysNotifyProperty.isShowIconOnDock = DEFAULT_SHOW_ICON_ON_DOCK;
    }
    qInfo() << ".............updateSysNotifyProperty end";
}

void NotifyManager::initConnect()
{
//    // 按键息屏
//    QDBusConnection::sessionBus().connect("com.deepin.daemon.Power"
//                                          , "/com/deepin/daemon/Power"
//                                          , "com.deepin.daemon.Power"
//                                          , "SuspendState", m_lockNotifyModel, SLOT(handleScreenFullBlack(QDBusMessage)));
//    // 自然息屏
//    QDBusConnection::sessionBus().connect("com.deepin.daemon.Power"
//                                          , "/com/deepin/daemon/Power"
//                                          , "com.deepin.daemon.Power"
//                                          , "ScreenFullBlack", m_lockNotifyModel, SLOT(refreshFold()));
//    connect(m_shellInter, &ShellInterface::swipeDown, m_notifyCenterModel, &NotifyCenterModel::refreshFold);
//    connect(DueShellManager::instance(), &DueShellManager::lockVisibleChanged, [this](bool visible){
//        if (visible)
//            return ;

//        m_notifyCenterModel->addLockNotifyList(m_lockNotifyModel);
//        m_lockNotifyModel->removeAllNotify();
//    });
    connect(m_notifySettings, &NotifySettings::appSettingChanged, this, [ = ] (const QString &id, const uint &item, QVariant var) {
        Q_EMIT AppInfoChanged(id, item, QDBusVariant(var));
    });
    connect(m_notifySettings, &NotifySettings::systemSettingChanged, this, [ = ] (const uint &item, QVariant var) {
        Q_EMIT SystemInfoChanged(item, QDBusVariant(var));
    });
    connect(m_notifySettings, &NotifySettings::appAddedSignal, this, [ = ] (const QString &id) {
        Q_EMIT AppAddedSignal(id);
        Q_EMIT appAdded(m_notifySettings->getAppSettings(id));
    });
    connect(m_notifySettings, &NotifySettings::appRemovedSignal, this, [ = ] (const QString &id) {
        Q_EMIT AppRemovedSignal(id);
        Q_EMIT appRemoved(id);
    });
    connect(m_lockNotifyModel, &LockNotifyModel::requstRemoveNotifyFromeDB, m_persistence, &Persistence::removeEntity);
    connect(m_lockNotifyModel, &LockNotifyModel::requstRemoveNotifyTableFromeDB, m_persistence, &Persistence::deleteTable);
//    connect(DueShellManager::instance(), &DueShellManager::actionInvoked, this, &NotifyManager::ActionInvoked, Qt::UniqueConnection);
//    connect(DueShellManager::instance(), &DueShellManager::notifyClosed, this, &NotifyManager::NotificationClosed, Qt::UniqueConnection);
    qInfo()<< "init end";
}

void NotifyManager::updateBannerPara(QQmlContext *context, EntityPtr entiy)
{
    QStringList idList, actionList;

    QStringList actionsName = entiy->actions();
    actionInfomation(actionsName, idList, actionList);

    if (context) {
        context->setContextProperty("appIcon", entiy->appIcon());
        context->setContextProperty("summaryMsg", entiy->summary());
        context->setContextProperty("showPreview", entiy->isShowPreview());
        context->setContextProperty("bodyMsg", entiy->body());
        context->setContextProperty("actions", actionList);
        context->setContextProperty("actionsID", idList);
    }
}

bool NotifyManager::isInTransit(EntityPtr notification) const
{
    return (notification->body().contains("%") && notification->actions().contains("cancel"));
}

void NotifyManager::addNotifyInLock(EntityPtr notification)
{
    qInfo() << ".........addNotifyInLock";
    m_persistence->addEntity(notification);
    m_lockNotifyModel->addNotify(notification);
//    if (m_sessionPowerInter->isValid()) {
//        QList<QVariant> argumentList;
//        argumentList << true;
//        m_sessionPowerInter->asyncCallWithArgumentList(QStringLiteral("WakeUpScreen"), argumentList);
//    } else {
//        qWarning() << "com.deepin.daemon.Power is not valid" << endl;
//    }
}

void NotifyManager::addInNotifyCenter(EntityPtr notification)
{
    qInfo() << "..........addInNotifyCenter";
    m_persistence->addEntity(notification);
    m_notifyCenterModel->addNotify(notification);
}

/**
 * @brief NotifyManager::createBanner 创建顶部消息横幅
 * @param entiy 消息数据
 * @param timeout 超时时间
 */
void NotifyManager::createBanner(EntityPtr entiy, int timeout)
{
    QPointer<NotifyWindow> view = new NotifyWindow;
    QQmlContext *context = view->rootContext();
    updateBannerPara(context, entiy);

    view->setEntityPtr(entiy);
    view->rootContext()->setContextProperty("osdcontrol", entiy->appIcon());
//    view->attached()->setWindowRadius(18);

    view->setSource(QUrl(QLatin1String("qrc:/src/qml/notification/Banner.qml")));
    QRect rect(QGuiApplication::primaryScreen()->size().width() / 2 - 300, 50, 600, 64);
    view->setGeometry(rect);

    view->transAnimation(AnimationType::Show);
    view->setFlags(Qt::WindowStaysOnTopHint | Qt::X11BypassWindowManagerHint);

    view->show();
    QQuickItem *item = view->rootObject();
    m_bannerList.append(view);

    connect(view, &NotifyWindow::hideAnimationFinished, [this, view]{
        EntityPtr notification = view->entityPtr();
        if (appNotifyProperty(notification->appName()).isShowInNotifyCenter && view->isPushInNotifyCenter()) {
            m_notifyCenterModel->addNotify(notification);
        } else {
            // 不压入通知中心,从数据库中删除该消息
            m_persistence->removeEntity(notification->appName(), QString::number(notification->id()));
        }
        m_bannerList.removeOne(view);
        view->deleteLater();
    });
    QObject::connect(item, SIGNAL(bannerRequstCancel()), view, SLOT(transAnimation()));
    QObject::connect(item, SIGNAL(bannerClicked()), view, SLOT(openApp()));
    QObject::connect(item, SIGNAL(requstInvoke(QString)), view, SLOT(bannerActionInvoke(QString)));

    // 0为永不消失，小于0为默认2s，>0为指定时间单位ms
    if (0 == timeout )
        return;

    int singleTime = OutTime;
    if (timeout > 0)
        singleTime = timeout;

    QTimer::singleShot(singleTime, this, [view](){
        if (!view.isNull())
            view->transAnimation(AnimationType::Hide);
    });
}

/**
 * @brief NotifyManager::pushBanner 推入一个消息横幅
 * @param notify 消息数据
 */
void NotifyManager::pushBanner(EntityPtr notify)
{
    qInfo() << " ...................startNotifyManager::pushBanner(EntityPtr notify)";
    if (!m_bannerList.isEmpty()) {
        QPointer<NotifyWindow> bannerWindow = m_bannerList[0];
        if (bannerWindow->entityPtr()->appName() == notify->appName()
                && notify->body().contains("%") && notify->actions().contains("cancel")) {
            QQmlContext *context = bannerWindow->rootContext();
            updateBannerPara(context, notify);
        } else {
            if (!bannerWindow.isNull()) {
                bannerWindow->transAnimation(AnimationType::Hide);
            }
            createBanner(notify, notify->timeout().toInt());
        }
    } else {
        createBanner(notify, notify->timeout().toInt());
        qInfo() << "..........end createBanner";
    }
}
