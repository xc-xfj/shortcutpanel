/*
 * Copyright (C) 2020 ~ 2021 Uniontech Software Technology Co.,Ltd.
 *
 * Author:     xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * Maintainer: xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "persistence.h"

#include <QStandardPaths>
#include <QDir>
#include <QDebug>
#include <QSqlError>
#include <QSqlRecord>
#include <QJsonArray>
#include <QJsonObject>
#include <QJsonDocument>

const QString ColumnId = "ID";
const QString ColumnIcon = "Icon";
const QString ColumnSummary = "Summary";
const QString ColumnBody = "Body";
const QString ColumnCTime = "CTime";
const QString ColumnAction = "Action";
const QString ColumnHint = "Hint";
const QString ColumnReplacesId = "ReplacesId";
const QString ColumnTimeout = "Timeout";
const QString Sqlite_Sequence = "sqlite_sequence";

/**
 * @brief Persistence::Persistence 通知消息数据库管理类
 * 通知数据按照应用名称分表放置，一个app就是一张表
 * @param parent
 */
Persistence::Persistence(QObject *parent)
    : QObject(parent)
{
    const QString dataDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);

    QDir dir(dataDir);
    if (!dir.exists()) {
        dir.mkpath(dataDir);
    }

    m_dbConnection = QSqlDatabase::addDatabase("QSQLITE", "QSQLITE");
    m_dbConnection.setDatabaseName(dataDir + "/" + "notify.db");
    if (!m_dbConnection.open()) {
        qWarning() << "open database error" << m_dbConnection.lastError().text();
    } else {
#ifdef QT_DEBUG
        qWarning() << "database open";
#endif
    }

    m_query = QSqlQuery(m_dbConnection);
    m_query.setForwardOnly(true);

    qInfo() << "..............dataDir" << dataDir;
}

/**
 * @brief Persistence::addEntity 数据库添加一条通知数据
 * @param entity 消息数据
 */
void Persistence::addEntity(EntityPtr entity)
{

    qInfo() << ".+++++++++++++++++++++++=addEntity";
    // "cancel"表示正在发送蓝牙文件,不需要发送到通知中心
    if (entity->body().contains("%") && entity->actions().contains("cancel")) {
        return;
    }

    QString tableName = entity->appName();
    if (!isTableExist(tableName))
        attemptCreateTable(tableName);
    QString sqlCmd =  QString("INSERT INTO %1 (").arg(specialSymbolsHandle(tableName));
    sqlCmd += ColumnIcon + ",";
    sqlCmd += ColumnSummary + ",";
    sqlCmd += ColumnBody + ",";
    sqlCmd += ColumnCTime + ",";
    sqlCmd += ColumnAction + ",";
    sqlCmd += ColumnHint + ",";
    sqlCmd += ColumnReplacesId + ",";
    sqlCmd += ColumnTimeout + ")";
    sqlCmd += "VALUES (:icon, :summary, :body, :ctime, :action, :hint, :replacesid, :timeout)";

    m_query.prepare(sqlCmd);
    m_query.bindValue(":icon", entity->appIcon());
    m_query.bindValue(":summary", entity->summary());
    m_query.bindValue(":body", entity->body());
    m_query.bindValue(":ctime", entity->ctime());

    // action
    QString action;
    foreach (QString text, entity->actions()) {
        action += text;
        action += ACTION_SEGMENT;
    }
    if (!action.isEmpty())
        action = action.mid(0, action.length() - 1);
    m_query.bindValue(":action", action);

    // hint
    m_query.bindValue(":hint", convertMapToString(entity->hints()));
    m_query.bindValue(":replacesid", entity->replacesId());
    m_query.bindValue(":timeout", entity->timeout());

    if (!m_query.exec()) {
        qWarning() << "insert value to database failed: " << m_query.lastError().text() << entity->id() << entity->ctime();
        return;
    } else {
#ifdef QT_DEBUG
        qDebug() << "insert value done, time is:" << entity->ctime();
#endif
    }

    // to get entity's id in database
    if (!m_query.exec(QString("SELECT last_insert_rowid() FROM %1;").arg(specialSymbolsHandle(tableName)))) {
        qWarning() << "get entity's id failed: " << m_query.lastError().text() << entity->id() << entity->ctime();
        return;
    } else {
        m_query.next();
        bool result;
        uint id = m_query.value(0).toString().toUInt(&result);
        if (result)
            entity->setId(id);
        else
            qWarning() << "Qstring to uint failed in ID:" << m_query.value(0).toString();
#ifdef QT_DEBUG
        qDebug() << "get entity's id done:" << entity->id();
#endif
        Q_EMIT entityAdded(entity);
    }
    qInfo() << "............. end addEntity";
}

/**
 * @brief Persistence::addEntity 数据库添加多条通知数据
 * @param entities 消息数据列表
 */
void Persistence::addEntity(QList<EntityPtr> entities)
{
    for (EntityPtr entity : entities) {
        addEntity(entity);
    }
}

/**
 * @brief Persistence::removeEntity 根据应用名称和消息id，从数据库删除一条通知
 * @param appName 应用名
 * @param id 通知id
 */
void Persistence::removeEntity(const QString &appName, const QString &id)
{
    m_query.prepare(QString("DELETE FROM %1 WHERE ID = (:id)").arg(specialSymbolsHandle(appName)));
    m_query.bindValue(":id", id);

    if (!m_query.exec()) {
        qWarning() << "remove value:" << id << "from database failed: " << m_query.lastError().text();
        return;
    } else {
#ifdef QT_DEBUG
        qDebug() << "remove value:" << id;
#endif
    }
}

/**
 * @brief Persistence::removeAll 清空数据库所有表数据
 */
void Persistence::removeAll()
{
    QStringList tables = m_dbConnection.tables();

    for (auto item : tables) {
        if (item == Sqlite_Sequence)
            continue;

        deleteTable(item);
    }

    // Remove the unused space
    if (!m_query.exec("VACUUM")) {
        qWarning() << "remove the unused space failed: " << m_query.lastError().text();
        return;
    } else {
#ifdef QT_DEBUG
        qDebug() << "remove the unused space done";
#endif
    }
}

/**
 * @brief Persistence::deleteTable 删除数据库中名字为tableName的表
 * @param tableName 表名
 */
void Persistence::deleteTable(const QString &tableName)
{
    QString sqlCmd = QString("DROP TABLE %1").arg(specialSymbolsHandle(tableName));
    m_query.prepare(sqlCmd);
    if (!m_query.exec()) {
        qWarning() << sqlCmd << ";delete table failed" << m_query.lastError().text();
    }
}

/**
 * @brief Persistence::clearTable 清空数据库中tableName表的中数据
 * @param tableName 表名
 */
void Persistence::clearTable(const QString &tableName)
{
    QString sqlCmd = QString("TRUNCATE TABLE %1").arg(specialSymbolsHandle(tableName));
    m_query.prepare(sqlCmd);
    if (!m_query.exec()) {
        qWarning() << sqlCmd << ";clear table failed" << m_query.lastError().text();
    }
}

/**
 * @brief Persistence::getAllNotify 获取所有通知
 * @return
 */
QList<EntityPtr> Persistence::getAllNotify()
{
    QList<EntityPtr> db_notification;
    QStringList tables = m_dbConnection.tables();
    QString json;
    QJsonArray notify_array;
    for (auto appName : tables) {
        if (appName == Sqlite_Sequence)
            continue;

        json = getAll(appName);
        notify_array = QJsonDocument::fromJson(json.toLocal8Bit().data()).array();

        foreach (auto notify, notify_array) {
            QJsonObject obj = notify.toObject();

            QStringList actions = obj.value("action").toString().split(ACTION_SEGMENT);

            auto notification = std::make_shared<NotifyEntity>(obj.value("name").toString(),
                                                               obj.value("id").toString(), obj.value("icon").toString(),
                                                               obj.value("summary").toString(),
                                                               obj.value("body").toString(),
                                                               actions, convertStringToMap(obj.value("hint").toString()),
                                                               obj.value("time").toString(),
                                                               obj.value("replacesid").toString(),
                                                               obj.value("timeout").toString(),
                                                               this);
            db_notification.append(notification);
        }
    }

    return db_notification;
}

/**
 * @brief Persistence::getAll 将表tableName内的所有通知转成字符串
 * @param tableName 表名
 * @return
 */
QString Persistence::getAll(const QString &tableName)
{
    QString sqlCmd = QString("SELECT ");
    sqlCmd += ColumnId + ",";
    sqlCmd += ColumnIcon + ",";
    sqlCmd += ColumnSummary + ",";
    sqlCmd += ColumnBody + ",";
    sqlCmd += ColumnCTime + ",";
    sqlCmd += ColumnAction + ",";
    sqlCmd += ColumnHint + ",";
    sqlCmd += ColumnReplacesId + ",";
    sqlCmd += ColumnTimeout + " FROM ";
    sqlCmd += specialSymbolsHandle(tableName);

    m_query.prepare(sqlCmd);

    if (!m_query.exec()) {
        qWarning() << "get all from database failed: " << m_query.lastError().text();
        return QString();
    } else {
#ifdef QT_DEBUG
        qDebug() << "get all done";
#endif
    }

    QJsonArray array1;
    while (m_query.next()) {
        QJsonObject obj {
            {"id", m_query.value(0).toString()},
            {"icon", m_query.value(1).toString()},
            {"summary", m_query.value(2).toString()},
            {"body", m_query.value(3).toString()},
            {"name", tableName},
            {"time", m_query.value(4).toString()},
            {"action", m_query.value(5).toString()},
            {"hint", m_query.value(6).toString()},
            {"replacesid", m_query.value(7).toString()},
            {"timeout", m_query.value(8).toString()},
        };
        array1.append(obj);
    }
    return QJsonDocument(array1).toJson();
}

/**
 * @brief Persistence::getTableRowCount 获取数据库中对应表的数据总数
 * @param tableName 表名
 * @return 数据总行数
 */
int Persistence::getTableRowCount(const QString &tableName)
{
    QString sqlCmd = QString("SELECT ");
    sqlCmd += ColumnId + ",";
    sqlCmd += ColumnIcon + ",";
    sqlCmd += ColumnSummary + ",";
    sqlCmd += ColumnBody + ",";
    sqlCmd += ColumnCTime + ",";
    sqlCmd += ColumnAction + ",";
    sqlCmd += ColumnHint + ",";
    sqlCmd += ColumnReplacesId + ",";
    sqlCmd += ColumnTimeout + " FROM ";
    sqlCmd += specialSymbolsHandle(tableName);

    m_query.prepare(sqlCmd);

    if (!m_query.exec()) {
        qWarning() << "get all from database failed: " << m_query.lastError().text();
        return -1;
    } else {
#ifdef QT_DEBUG
        qDebug() << "get all done";
#endif
    }

    int result = 0;
    while (m_query.next()) {
        result++;
    }
    return result;
}

/**
 * @brief Persistence::attemptCreateTable 在数据库中建立表，记录通知消息
 * @param appName 表名，应用名为表名
 */
void Persistence::attemptCreateTable(const QString &appName)
{
    qInfo() << "+++++++++++++++++attemptCreateTable";
    QString text = QString("CREATE TABLE IF NOT EXISTS %1("
                           "%2 INTEGER PRIMARY KEY   AUTOINCREMENT,").arg(specialSymbolsHandle(appName), ColumnId);
    text += ColumnIcon + " TEXT,";
    text += ColumnSummary + " TEXT,";
    text += ColumnBody + " TEXT,";
    text += ColumnCTime + " TEXT,";
    text += ColumnAction + " TEXT,";
    text += ColumnHint + " TEXT,";
    text += ColumnReplacesId + " TEXT,";
    text += ColumnTimeout + " TEXT)";

    m_query.prepare(text);
    qInfo() << "...............m_query.prepare(text)";

    if (!m_query.exec()) {
        qWarning() << "create table failed" << m_query.lastError().text();
    }
    qInfo() << "...............end attemptCreateTable";
}

/**
 * @brief Persistence::convertMapToString 将QVariantMap类型转换为QString类型
 * @param map
 * @return
 */
QString Persistence::convertMapToString(const QVariantMap &map)
{
    QString text;

    QMapIterator<QString, QVariant> it(map);
    while (it.hasNext()) {
        it.next();
        QString key = it.key();
        text += key;
        text += KEYVALUE_SEGMENT;
        QString value = it.value().toString();
        text += value;
        text += HINT_SEGMENT;
    }

    return text;
}

/**
 * @brief Persistence::convertStringToMap 将QString类型转换为QVariantMap类型
 * @param text
 * @return
 */
QVariantMap Persistence::convertStringToMap(const QString &text)
{
    QVariantMap map;

    QStringList keyValueList = text.split(HINT_SEGMENT);
    foreach (QString text, keyValueList) {
        QStringList list = text.split(KEYVALUE_SEGMENT);
        if (list.size() != 2)
            continue;
        QString key = list[0];
        QVariant value = QVariant::fromValue(list[1]);

        map.insert(key, value);
    }

    return map;
}

/**
 * @brief Persistence::isTableExist 查询数据库中是否存在名为tableName的表
 * @param tableName 表名
 * @return
 */
bool Persistence::isTableExist(const QString &tableName)
{
    QString sqlCmd = QString("SELECT * FROM SQLITE_MASTER WHERE TYPE='table' AND NAME='%1'").arg(specialSymbolsHandle(tableName));
    if (m_query.exec(sqlCmd)) {
        if (m_query.next())
            return true;
        else
            return false;
    } else {
        return false;
    }
}

/**
 * @brief Persistence::isAttributeValid 判断数据库表中的属性名称是否有效
 * @param tableName 表名
 * @param attributeName 属性名
 * @return 有效返回true,无效返回false
 */
bool Persistence::isAttributeValid(const QString &tableName, const QString &attributeName)
{
    QString tableNameStr = specialSymbolsHandle(tableName);
    QString sqlCmd = QString("SELECT * FROM SQLITE_MASTER WHERE TYPE='table' AND NAME='%1'").arg(tableNameStr);
    if (m_query.exec(sqlCmd)) {
        if (m_query.next()) {
            sqlCmd = QString("SELECT * FROM %2").arg(tableNameStr);
            if (m_query.exec(sqlCmd)) {
                QSqlRecord record = m_query.record();
                int index = record.indexOf(attributeName);
                if (index == -1) {
                    return false;
                } else {
                    return true;
                }
            } else {
                qDebug() << sqlCmd << ",lastError:" << m_query.lastError().text();
                return false;
            }
        } else { // table not exist
            return false;
        }
    } else {// sql error
        qDebug() << sqlCmd << ",lastError:" << m_query.lastError().text();
        return false;
    }
}

/**
 * @brief Persistence::addAttributeToTable 添加一个属性到数据库表中
 * @param tableName 表名
 * @param attributeName 属性名
 * @return
 */
bool Persistence::addAttributeToTable(const QString &tableName, const QString &attributeName)
{
    QString sqlCmd = QString("alter table %1 add %2 TEXT").arg(specialSymbolsHandle(tableName), attributeName);
    return m_query.exec(sqlCmd);
}

/**
 * @brief Persistence::specialSymbolsHandle 字符转义处理
 * @param text
 * @return
 */
QString Persistence::specialSymbolsHandle(const QString &text)
{
    QString handleSrr = text;
    handleSrr.append("]");
    return handleSrr.insert(0, "[");
}
