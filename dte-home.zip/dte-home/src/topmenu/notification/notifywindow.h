/*
 * Copyright (C) 2020 ~ 2021 Uniontech Software Technology Co.,Ltd.
 *
 * Author:     xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * Maintainer: xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef NOTIFYWINDOW_H
#define NOTIFYWINDOW_H

#include "enumtype.h"
#include "constant.h"

#include <QQuickView>
//#include <DQuickWindow>

//DQUICK_USE_NAMESPACE

class QParallelAnimationGroup;
class QPropertyAnimation;

enum AnimationType{
    Show,
    Hide
};

class NotifyWindow : public QQuickView
{
    Q_OBJECT
public:
    explicit NotifyWindow(QWindow *parent = nullptr);
    virtual ~NotifyWindow() {}

    EntityPtr entityPtr() const;
    void setAnimatinTime(const int &time) { m_animatinTime = time; }
    void setEntityPtr(const EntityPtr &entity);

    void setIsPushInNotifyCenter(bool isPush);
    bool isPushInNotifyCenter() const { return m_isPushInNotifyCenter; }

    void setOrientation(EnumType::Orientation orientation);
    EnumType::Orientation getOrientation() { return m_orientation; }

    void setAlignment(EnumType::Alignment alignment);
    EnumType::Alignment getAlignment() { return m_alignments; }

public Q_SLOTS:
    void transAnimation(AnimationType type = AnimationType::Hide);
    void openApp();
    void bannerActionInvoke(const QString &id);
    virtual void handleAnimationFinished();

Q_SIGNALS:
    /**
     * @brief hideAnimationFinished 消失动画完成信号
     */
    void hideAnimationFinished();

private:
    void init();
    void initConnect();
    void closeMultiTaskingView();

protected:
    EnumType::Orientation m_orientation = EnumType::Horizontal;        // 方向
    EnumType::Alignment m_alignments = EnumType::Top;                  // 对齐方式（与方向一起确定位置）
    AnimationType m_AnimationType;

private:
    QParallelAnimationGroup *m_aniGroup;        // 并行动画组
    QPropertyAnimation *m_posAnimation;         // 位移动画
    QPropertyAnimation *m_opacityAnimation;     // 透明度动画
    int m_animatinTime;                         // 动画时间
    EntityPtr m_entity;                         // 消息数据
    bool m_isOpenApp;
    bool m_isPushInNotifyCenter;
};

#endif // NOTIFYWINDOW_H
