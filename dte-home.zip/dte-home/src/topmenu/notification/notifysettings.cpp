/*
 * Copyright (C) 2020 ~ 2021 Deepin Technology Co., Ltd.
 *
 * Author:     weizhixiang <weizhixiang@uniontech.com>
 *
 * Maintainer: weizhixiang <weizhixiang@uniontech.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "notifysettings.h"
#include "constant.h"

#include <DDesktopEntry>

#include <QGSettings/QGSettings>
#include <QTimer>
#include <QVariant>
#include <QJsonObject>
#include <QJsonDocument>
#include <QByteArray>
#include <QStringList>
#include <QDBusConnectionInterface>

DCORE_USE_NAMESPACE

const QString schemaKey = "com.deepin.dde.notifications";
const QString schemaPath = "/com/deepin/dde/notifications/";
const QString appSchemaKey = "com.deepin.dde.notifications.applications";
const QString appSchemaPath = "/com/deepin/dde/notifications/applications/%1/";
const QString launcherKey = "com.deepin.dde.daemon.Launcher";
const QString launcherPath = "/com/deepin/dde/daemon/Launcher";

/**
 * @brief NotifySettings::NotifySettings 通知配置
 * @param parent
 */
NotifySettings::NotifySettings(QObject *parent)
    : QObject(parent)
    , m_systemSetting(new QGSettings(schemaKey.toLocal8Bit(), schemaPath.toLocal8Bit(), this))
{
    QDBusConnectionInterface *ifc = QDBusConnection::sessionBus().interface();
    if (!ifc->isServiceRegistered(launcherKey)) {
        connect(ifc, &QDBusConnectionInterface::serviceOwnerChanged, this, [ = ](const QString & name, const QString & oldOwner, const QString & newOwner) {
            Q_UNUSED(oldOwner)
            if (name == launcherKey && !newOwner.isEmpty()) {
//                FREE_POINT(m_launcherInter);
//                m_launcherInter = new LauncherInter(launcherKey, launcherPath, QDBusConnection::sessionBus(), this);
                initAllSettings();
            }
        });
    } else {
//        m_launcherInter = new LauncherInter(launcherKey, launcherPath, QDBusConnection::sessionBus(), this);
        initAllSettings();
    }

    if (!QGSettings::isSchemaInstalled("com.deepin.dde.notification")) {
        qDebug()<<"System configuration fetch failed!";
    }
}

/**
 * @brief NotifySettings::initAllSettings 初始化所有设置
 */
void NotifySettings::initAllSettings()
{
//    registerLauncherItemInfoListMetaType();
//    registerLauncherItemInfoMetaType();
//    connect(m_launcherInter, &LauncherInter::ItemChanged, this, [ = ] (QString action, LauncherItemInfo info, qlonglong id) {
//        Q_UNUSED(id)
//        if (action == "deleted") {
//            appRemoved(info.ID);
//        } else if (action == "created") {
//            appAdded(info);
//        }
//    });

//    LauncherItemInfoList itemInfoList = m_launcherInter->GetAllItemInfos();
    QStringList appList = m_systemSetting->get("app-list").toStringList();

//    foreach(const LauncherItemInfo &item, itemInfoList) {
//        DDesktopEntry desktopInfo(item.Path);
//        if (IgnoreList.contains(item.ID) || desktopInfo.rawValue("X-Created-By") == "Deepin WINE Team")
//            continue;

//        if (appList.contains(item.ID)) {
//            // 修改系统语言后需要更新翻译
//            QGSettings itemSetting(appSchemaKey.toLocal8Bit(), appSchemaPath.arg(item.ID).toLocal8Bit(), this);
//            itemSetting.set( "app-name", item.Name);
//            continue;
//        }
//        appList.append(item.ID);
//        m_systemSetting->set("app-list", appList);
//        appAdded(item);
//    }
}

/**
 * @brief NotifySettings::setAppSetting 设置应用通知配置
 * @param id 应用id
 * @param item 配置项
 * @param var 配置参数
 */
void NotifySettings::setAppSetting(const QString &id, const NotifySettings::AppConfigurationItem &item, const QVariant &var)
{
    QGSettings itemSetting(appSchemaKey.toLocal8Bit(), appSchemaPath.arg(id).toLocal8Bit(), this);
    switch (item) {
    case AppName:
        itemSetting.set("app-name", var);
        break;
    case AppIcon:
        itemSetting.set("app-icon", var);
        break;
    case EnableNotification:
        itemSetting.set("enable-notification", var);
        break;
    case EnablePreview:
        itemSetting.set("enable-preview", var);
        break;
    case EnableSound:
        itemSetting.set("enable-sound", var);
        break;
    case ShowInNotificationCenter:
        itemSetting.set("show-in-notification-center", var);
        break;
    case LockScreenShowNotification:
        itemSetting.set("lockscreen-show-notification", var);
        break;
    }

    Q_EMIT appSettingChanged(id, item, var);
}

/**
 * @brief NotifySettings::getAppSetting 获取应用通知配置
 * @param id 应用id
 * @param item 配置项
 * @return 项对应配置
 */
QVariant NotifySettings::getAppSetting(const QString &id, const NotifySettings::AppConfigurationItem &item)
{
    QGSettings itemSetting(appSchemaKey.toLocal8Bit(), appSchemaPath.arg(id).toLocal8Bit(), this);

    QVariant results;
    switch (item) {
    case AppName:
        results = itemSetting.get("app-name");
        break;
    case AppIcon:
        results = itemSetting.get("app-icon");
        break;
    case EnableNotification:
        results = itemSetting.get("enable-notification");
        break;
    case EnablePreview:
        results = itemSetting.get("enable-preview");
        break;
    case EnableSound:
        results = itemSetting.get("enable-sound");
        break;
    case ShowInNotificationCenter:
        results = itemSetting.get("show-in-notification-center");
        break;
    case LockScreenShowNotification:
        results = itemSetting.get("lockscreen-show-notification");
        break;
    }
    return results;
}

/**
 * @brief NotifySettings::setSystemSetting 设置系统通知配置
 * @param item 配置项
 * @param var 配置参数
 */
void NotifySettings::setSystemSetting(const NotifySettings::SystemConfigurationItem &item, const QVariant &var)
{
    switch (item) {
    case DnDMode:
        m_systemSetting->set("dndmode", var);
        break;
    case LockScreenOpenDnDMode:
        m_systemSetting->set("lockscreen-open-dndmode", var);
        break;
    case OpenByTimeInterval:
        m_systemSetting->set("open-by-time-interval", var);
        break;
    case StartTime:
        m_systemSetting->set("start-time", var);
        break;
    case EndTime:
        m_systemSetting->set("end-time", var);
        break;
    }

    Q_EMIT systemSettingChanged(item, var);
}

/**
 * @brief NotifySettings::getSystemSetting 获取系统通知配置
 * @param item 配置项
 * @return 项对应配置
 */
QVariant NotifySettings::getSystemSetting(const NotifySettings::SystemConfigurationItem &item)
{
    QVariant results;
    switch (item) {
    case DnDMode:
        results = m_systemSetting->get("dndmode");
        break;
    case LockScreenOpenDnDMode:
        results = m_systemSetting->get("lockscreen-open-dndmode");
        break;
    case OpenByTimeInterval:
        results = m_systemSetting->get("open-by-time-interval");
        break;
    case StartTime:
        results = m_systemSetting->get("start-time");
        break;
    case EndTime:
        results = m_systemSetting->get("end-time");
        break;
    }
    return results;
}

/**
 * @brief NotifySettings::getAppLists 获取应用列表
 * @return
 */
QStringList NotifySettings::getAppLists()
{
    return m_systemSetting->get("app-list").toStringList();
}

/**
 * @brief NotifySettings::appAdded 添加应用
 * @param info 应用信息
 */
//void NotifySettings::appAdded(const LauncherItemInfo &info)
//{
//    QStringList appList = m_systemSetting->get("app-list").toStringList();
//    if (!appList.contains(info.ID)) {
//        appList.append(info.ID);
//        m_systemSetting->set("app-list", appList);
//    }

//    QGSettings itemSetting(appSchemaKey.toLocal8Bit(), appSchemaPath.arg(info.ID).toLocal8Bit(), this);

//    itemSetting.set("app-name", info.Name);
//    itemSetting.set("app-icon", info.Icon);
//    itemSetting.set("enable-notification", DEFAULT_ALLOW_NOTIFY);
//    itemSetting.set("enable-preview", DEFAULT_SHOW_NOTIFY_PREVIEW);
//    itemSetting.set("enable-sound", DEFAULT_NOTIFY_SOUND);
//    itemSetting.set("show-in-notification-center", DEFAULT_ONLY_IN_NOTIFY);
//    itemSetting.set("lockscreen-show-notification", DEFAULT_LOCK_SHOW_NOTIFY);

//    Q_EMIT appAddedSignal(info.ID);
//}

/**
 * @brief NotifySettings::appRemoved 移除应用
 * @param id 应用id
 */
void NotifySettings::appRemoved(const QString &id)
{
    QStringList appList = m_systemSetting->get("app-list").toStringList();
    if (appList.contains(id)) {
        appList.removeOne(id);
        m_systemSetting->set("app-list", appList);
    }

    QGSettings itemSetting(appSchemaKey.toLocal8Bit(), appSchemaPath.arg(id).toLocal8Bit(), this);
    itemSetting.reset("app-name");
    itemSetting.reset("app-icon");
    itemSetting.reset("enable-notification");
    itemSetting.reset("enable-preview");
    itemSetting.reset("enable-sound");
    itemSetting.reset("show-in-notification-center");
    itemSetting.reset("lockscreen-show-notification");

    Q_EMIT appRemovedSignal(id);
}

/**
 * @brief NotifySettings::setAppSetting 设置应用通知配置
 * @param settings 应用通知配置信息
 */
void NotifySettings::setAppSetting(QString settings)
{
    QJsonObject jsonObj = QJsonDocument::fromJson(settings.toLocal8Bit()).object();
    QString id = jsonObj.begin().key();
    jsonObj = jsonObj.begin().value().toObject();
    QGSettings itemSetting(appSchemaKey.toLocal8Bit(), appSchemaPath.arg(id).toLocal8Bit(), this);
    itemSetting.set("enable-notification", jsonObj[AllowNotifyStr].toBool());
    itemSetting.set("show-in-notification-center", jsonObj[ShowInNotifyCenterStr].toBool());
    itemSetting.set("lockscreen-show-notification", jsonObj[LockShowNotifyStr].toBool());
    itemSetting.set("enable-preview", jsonObj[ShowNotifyPreviewStr].toBool());
    itemSetting.set("enable-sound", jsonObj[NotificationSoundStr].toBool());
    itemSetting.set("app-icon", jsonObj[AppIconStr].toString());
    itemSetting.set("app-name", jsonObj[AppNameStr].toString());
}

/**
 * @brief NotifySettings::getAppSettings 获取应用通知配置
 * @param id 应用id
 * @return 配置信息
 */
QString NotifySettings::getAppSettings(const QString &id)
{
    QGSettings itemSetting(appSchemaKey.toLocal8Bit(), appSchemaPath.arg(id).toLocal8Bit(), this);
    QJsonObject jsonObj;
    jsonObj.insert(AllowNotifyStr, itemSetting.get("enable-notification").toJsonValue());
    jsonObj.insert(ShowInNotifyCenterStr, itemSetting.get("show-in-notification-center").toJsonValue());
    jsonObj.insert(LockShowNotifyStr, itemSetting.get("lockscreen-show-notification").toJsonValue());
    jsonObj.insert(ShowNotifyPreviewStr, itemSetting.get("enable-preview").toJsonValue());
    jsonObj.insert(NotificationSoundStr, itemSetting.get("enable-sound").toJsonValue());
    jsonObj.insert(AppIconStr, itemSetting.get("app-icon").toJsonValue());
    jsonObj.insert(AppNameStr, itemSetting.get("app-name").toJsonValue());
    QJsonObject appSetingObj;
    appSetingObj[id] = jsonObj;
    return QString(QJsonDocument(appSetingObj).toJson());
}

/**
 * @brief NotifySettings::setSystemSetting 设置系统通知配置
 * @param settings 系统通知配置信息
 */
void NotifySettings::setSystemSetting(QString settings)
{
    QJsonObject jsonObj = QJsonDocument::fromJson(settings.toUtf8()).object();
    jsonObj = jsonObj.begin().value().toObject();
    if (jsonObj.contains(DoNotDisturbStr)) {
        m_systemSetting->set("dndmode", jsonObj[DoNotDisturbStr].toBool());
        Q_EMIT systemSettingChanged(DnDMode, jsonObj[DoNotDisturbStr].toBool());
    }
    if (jsonObj.contains(ScreenLockedStr)) {
        m_systemSetting->set("lockscreen-open-dndmode", jsonObj[ScreenLockedStr].toBool());
    }
    if (jsonObj.contains(TimeSlotStr)) {
        m_systemSetting->set("open-by-time-interval", jsonObj[TimeSlotStr].toBool());
    }
    if (jsonObj.contains(StartTimeStr)) {
        m_systemSetting->set("start-time", jsonObj[StartTimeStr].toString());
    }
    if (jsonObj.contains(EndTimeStr)) {
        m_systemSetting->set("end-time", jsonObj[EndTimeStr].toString());
    }
}

/**
 * @brief NotifySettings::getSystemSetings 获取系统通知配置
 * @return 配置信息
 */
QString NotifySettings::getSystemSetings()
{
    QJsonObject jsonObj;
    jsonObj.insert(DoNotDisturbStr, m_systemSetting->get("dndmode").toJsonValue());
    jsonObj.insert(ScreenLockedStr, m_systemSetting->get("lockscreen-open-dndmode").toJsonValue());
    jsonObj.insert(TimeSlotStr, m_systemSetting->get("open-by-time-interval").toJsonValue());
    jsonObj.insert(StartTimeStr, m_systemSetting->get("start-time").toJsonValue());
    jsonObj.insert(EndTimeStr, m_systemSetting->get("end-time").toJsonValue());
    QJsonObject SystemSetingObj;
    SystemSetingObj[SystemNotifySettingStr] = jsonObj;
    return QString(QJsonDocument(SystemSetingObj).toJson());
}

/**
 * @brief NotifySettings::setAllSetting 设置所有通知配置
 * @param settings 所有通知配置信息
 */
void NotifySettings::setAllSetting(QString settings)
{
    // 未被使用的接口废弃
    Q_UNUSED(settings)
}

/**
 * @brief NotifySettings::getAllSetings 获取所有通知配置信息
 * @return
 */
QString NotifySettings::getAllSetings()
{
    QStringList appList = m_systemSetting->get("app-list").toStringList();

    QJsonObject jsonObj;
    foreach (const auto &id, appList) {
        QGSettings itemSetting(appSchemaKey.toLocal8Bit(), appSchemaPath.arg(id).toLocal8Bit(), this);
        QJsonObject itemObj;
        itemObj.insert(AllowNotifyStr, itemSetting.get("enable-notification").toJsonValue());
        itemObj.insert(ShowInNotifyCenterStr, itemSetting.get("show-in-notification-center").toJsonValue());
        itemObj.insert(LockShowNotifyStr, itemSetting.get("lockscreen-show-notification").toJsonValue());
        itemObj.insert(ShowNotifyPreviewStr, itemSetting.get("enable-preview").toJsonValue());
        itemObj.insert(NotificationSoundStr, itemSetting.get("enable-sound").toJsonValue());
        itemObj.insert(AppIconStr, itemSetting.get("app-icon").toJsonValue());
        itemObj.insert(AppNameStr, itemSetting.get("app-name").toJsonValue());
        jsonObj[id] = itemObj;
    }

    QJsonObject Obj;
    Obj.insert(DoNotDisturbStr, m_systemSetting->get("dndmode").toJsonValue());
    Obj.insert(ScreenLockedStr, m_systemSetting->get("lockscreen-open-dndmode").toJsonValue());
    Obj.insert(TimeSlotStr, m_systemSetting->get("open-by-time-interval").toJsonValue());
    Obj.insert(StartTimeStr, m_systemSetting->get("start-time").toJsonValue());
    Obj.insert(EndTimeStr, m_systemSetting->get("end-time").toJsonValue());
    jsonObj[SystemNotifySettingStr] = Obj;
    return QString(QJsonDocument(jsonObj).toJson());
}
