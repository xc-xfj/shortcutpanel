/*
 * Copyright (C) 2020 ~ 2021 Uniontech Software Technology Co.,Ltd.
 *
 * Author:     xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * Maintainer: xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "notifyentity.h"

/**
 * @brief NotifyEntity::NotifyEntity 通知消息数据结构
 * @param appName
 * @param id
 * @param appIcon
 * @param summary
 * @param body
 * @param actions
 * @param hints
 * @param ctime
 * @param replacesId
 * @param timeout
 * @param parent
 */
NotifyEntity::NotifyEntity(const QString &appName, const QString &id,
                                       const QString &appIcon, const QString &summary,
                                       const QString &body, const QStringList &actions,
                                       const QVariantMap hints, const QString &ctime,
                                       const QString &replacesId, const QString &timeout,
                                       QObject *parent)
    : QObject(parent)
    , m_appName(appName)
    , m_id(id.toUInt())
    , m_appIcon(appIcon)
    , m_summary(summary)
    , m_body(body)
    , m_actions(actions)
    , m_hints(hints)
    , m_ctime(ctime)
    , m_replacesId(replacesId)
    , m_timeout(timeout)
    , m_isTitle(false)
    , m_hideCount(0)
    , m_showPreview(true)
    , m_index(0)
    , m_showInNotifyCenter(true)
    , m_zorder(1)
    , m_expandParentRow(-1)
    , m_parentPosY(-1)
    , m_isFlicked(false)
{

}

NotifyEntity::NotifyEntity(const NotifyEntity &notify)
    : NotifyEntity(notify.appName(), QString::number(notify.id()), notify.appIcon(), notify.summary(),
                   notify.body(), notify.actions(), notify.hints(), notify.ctime(),
                   notify.replacesId(), notify.timeout())
{

}
