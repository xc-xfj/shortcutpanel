/*
 * Copyright (C) 2020 ~ 2021 Uniontech Software Technology Co.,Ltd.
 *
 * Author:     xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * Maintainer: xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef LOCKNOTIFYMODEL_H
#define LOCKNOTIFYMODEL_H

#include "constant.h"
#include "public_func.h"

//#include <com_deepin_daemon_timedate.h>

#include <QAbstractListModel>

//using Timedate = com::deepin::daemon::Timedate;

const int MaxUnFoldCount = 3;                       // 最大不折叠数
const int OVERLAPTIMEOUT_7_DAY = 7 * 24 * 60 * 60;  // 超时时间

class QGSettings;
class QDBusMessage;

/**
 * @brief The ListItem struct 消息分组数据结构
 */
struct ListItem {
    QString appName;                // 应用名称
    QString lastTimeStamp;          // 此组应用最新的时间
    bool expand = true;             // 是否展开
    bool isBlank = false;           // 组上方是否有间距
    QList<EntityPtr> showList;      // 显示列表
    QList<EntityPtr> hideList;      // 隐藏列表
};

class LockNotifyModel : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(QString newNotify READ newNotify WRITE setNewNotify NOTIFY newNotifyChanged)
public:
    explicit LockNotifyModel(QObject *parent = nullptr);
    QList<EntityPtr> allNotify();

    QVariant data(const QModelIndex &index, int role) const override;
    bool setData(const QModelIndex &index, const QVariant &value, int role = Qt::EditRole) override;
    Q_INVOKABLE int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    Q_INVOKABLE int appFirstNotifyRow(const QString &appName) const;
    Q_INVOKABLE void foldAppNotify(const QString &appName);
    Q_INVOKABLE void expandAppNotify(const QString &appName, int expandParentRow, double parentPosY);
    Q_INVOKABLE QString appName(int row) const;
    Q_INVOKABLE void setIsFlicked(int row, const QVariant &value);
    Q_INVOKABLE int state(int row) const;
    Q_INVOKABLE QString appFromDesktop(const QString &desktopName) const;
    Q_INVOKABLE int appCount(const QString &appName) const;
    Q_INVOKABLE void resetFlickable();

    QString m_newNotify = "sssss";
    QString newNotify() { return m_newNotify;}

    void setNewNotify(QString msg) {m_newNotify = msg;}

Q_SIGNALS:
    void newNotifyChanged();

public:

    /**
     * @brief setCurrentExpandAppName 设置当前展开APP组名字
     * @param appName
     */
    Q_INVOKABLE void setCurrentExpandAppName(const QString &appName) { m_currentExpandAppName = appName; }

    /**
     * @brief setCurrentExpandCount 设置当前展开消息数量
     * @param count
     */
    Q_INVOKABLE void setCurrentExpandCount(const int &count) { m_currentExpandCount = count; }

    /**
     * @brief currentExpandAppName 返回当前展开的消息组应用名
     * @return
     */
    Q_INVOKABLE QString currentExpandAppName() const { return m_currentExpandAppName; }

    /**
     * @brief currentExpandCount 返回当前展开消息数量
     * @return
     */
    Q_INVOKABLE int currentExpandCount() const { return m_currentExpandCount; }

    /**
     * @brief preNotifyCount 返回自由显示的消息数量
     * @return
     */
    Q_INVOKABLE int preNotifyCount() const { return m_preNotifyList.count(); }

public Q_SLOTS:
    void addNotify(EntityPtr entity);
    void subNotify();
    void removeTimeOutNotify();
    void refreshFold();
    void handleScreenFullBlack(QDBusMessage msg);
    Q_INVOKABLE void removeNotify(int row);
    Q_INVOKABLE virtual void removeAppGroup(int row);
    Q_INVOKABLE virtual void removeAllNotify();
    Q_INVOKABLE bool isTimeOutDelete() const;
    Q_INVOKABLE virtual void readNotify(const QString &appName, int row);
    Q_INVOKABLE virtual void notifyActionInvoke(const QString &actionid, const QVariantMap &hints, int row);
    Q_INVOKABLE void breakLockAuthConnect();

    /**
     * @brief flickedRow 返回当前处于左滑状态的行
     * @return
     */
    Q_INVOKABLE int flickedRow() { return m_flickedRow; }

Q_SIGNALS:
    /**
     * @brief allNotifyRemoved 消息清空时发送此信号
     */
    void allNotifyRemoved();

    /**
     * @brief firstNotifyAdded 添加第一条消息时发送此信号
     */
    void firstNotifyAdded();

    /**
     * @brief newNotifyAdded 新消息添加信号
     */
    void newNotifyAdded();
    void updateBubbleTime();
    void requstRemoveNotifyFromeDB(const QString &appName, const QString &id);
    void requstRemoveNotifyTableFromeDB(const QString &appName);

protected:
    QHash<int, QByteArray> roleNames() const override;
    void addAppData(EntityPtr entity);
    EntityPtr entityByRow(int row) const;
    bool checkTimeOut(EntityPtr ptr, int sec);
    void insertBlank(int index, int insertRow);
    void removeBlank(int index, int removeRow);

    /**
     * @brief removeNotifyFromeDB 从数据库中删除消息记录
     * @param row 视图项行
     * @return 是否删除成功
     */
    virtual void removeNotifyFromeDB(int row);

    /**
     * @brief removeAppGroupFromeDB 从数据库中删除与entity同名折叠消息
     * @param entity
     */
    virtual void removeAppGroupFromeDB(EntityPtr entity);

    /**
     * @brief removeAllFromeDB 清空数据库
     */
    virtual void removeAllFromeDB() { }

protected:
    QList<ListItem> m_notifyGroupList;   // 应用组信息，用于应用分类
    QList<EntityPtr> m_preNotifyList;   // 上方列表，用于新消息展示上方

private:
    QHash<int, QByteArray> m_roleNames;
    int m_currentExpandCount;               // 当前展开消息组数量
//    Timedate *m_timedateInter;
    QGSettings *m_gsettings;
    QString m_currentExpandAppName;         // 当前展开消息组名
    QVector<int> m_flickVector;             // 轻扫role
    int m_flickedRow;                       // 上一个向左轻扫行
    QMetaObject::Connection m_readAuthConnection;
    QMetaObject::Connection m_invokeAuthConnection;
};

#endif // LOCKNOTIFYMODEL_H
