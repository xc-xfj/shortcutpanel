/*
 * Copyright (C) 2020 ~ 2021 Uniontech Software Technology Co.,Ltd.
 *
 * Author:     xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * Maintainer: xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef PERSISTENCE_H
#define PERSISTENCE_H

#include "constant.h"

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariantMap>

#define ACTION_SEGMENT ("|")
#define HINT_SEGMENT ("|")
#define KEYVALUE_SEGMENT ("!!!")

class Persistence : public QObject
{
    Q_OBJECT
public:
    explicit Persistence(QObject *parent = nullptr);

    void addEntity(EntityPtr entity);
    void addEntity(QList<EntityPtr> entities);
    void removeAll();
    void clearTable(const QString &tableName);
    QList<EntityPtr> getAllNotify();
    QString getAll(const QString &tableName);
    int getTableRowCount(const QString &tableName);

public Q_SLOTS:
    void removeEntity(const QString &appName, const QString &id);
    void deleteTable(const QString &tableName);

private:
    void attemptCreateTable(const QString &appName);
    QString convertMapToString(const QVariantMap &map);
    QVariantMap convertStringToMap(const QString &text);
    bool isTableExist(const QString &tableName);
    bool isAttributeValid(const QString &tableName, const QString &attributeName);
    bool addAttributeToTable(const QString &tableName, const QString &attributeName);
    QString specialSymbolsHandle(const QString &text);

Q_SIGNALS:
    /**
     * @brief EntityAdded 数据库中消息增加信号
     * @param entity 消息数据
     */
    void entityAdded(EntityPtr entity);

private:
    QSqlDatabase m_dbConnection; // 数据库连接
    QSqlQuery m_query;          // 数据库查询
};

#endif // PERSISTENCE_H
