/*
 * Copyright (C) 2020 ~ 2021 Uniontech Software Technology Co.,Ltd.
 *
 * Author:     xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * Maintainer: xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef NOTIFYCENTERMODEL_H
#define NOTIFYCENTERMODEL_H

#include "locknotifymodel.h"

class Persistence;
class ShellInterface;

class NotifyCenterModel : public LockNotifyModel
{
    Q_OBJECT
public:
    explicit NotifyCenterModel(QObject *parent = nullptr, Persistence *database = nullptr);
    Q_INVOKABLE void addLockNotifyList(LockNotifyModel *lockModel);
    Q_INVOKABLE QString getInfo() {return "xxxxxxxxxxxxxxxxxxxxxxx";}

public Q_SLOTS:
    void removeNotifyFromeDB(int row) override;
    void removeAppGroupFromeDB(EntityPtr entity) override;
    void removeAllFromeDB() override;
    void readNotify(const QString &appName, int row) override;
    void notifyActionInvoke(const QString &actionid, const QVariantMap &hints, int row) override;

private:
    void initData();

private:
    Persistence *m_database;  // 数据库
    ShellInterface *m_shellInter;
};

#endif // NOTIFYCENTERMODEL_H
