/*
 * Copyright (C) 2020 ~ 2021 Uniontech Software Technology Co.,Ltd.
 *
 * Author:     xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * Maintainer: xiaoyaobing <xiaoyaobing@uniontech.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef NOTIFYENTITY_H
#define NOTIFYENTITY_H

#include "enumtype.h"

#include <QObject>
#include <QVariantMap>

class NotifyEntity : public QObject
{
    Q_OBJECT

public:
    explicit NotifyEntity(const QString &appName = QString(), const QString &id = QString(),
                          const QString &appIcon = QString(), const QString &summary = QString(),
                          const QString &body = QString(), const QStringList &actions = QStringList(),
                          const QVariantMap hints = QVariantMap(), const QString &ctime = QString(),
                          const QString &replacesId = QString(), const QString &timeout = QString(),
                          QObject *parent = nullptr);

    NotifyEntity(const NotifyEntity &notify);

    inline QString appName() const { return m_appName; }
    inline void setAppName(const QString &appName) { m_appName = appName; }

    inline uint id() const { return m_id; }
    inline void setId(const uint &id) { m_id = id; }

    inline QString appIcon() const { return m_appIcon; }
    inline void setAppIcon(const QString &appIcon) { m_appIcon = appIcon; }

    inline QString summary() const { return m_summary; }
    inline void setSummary(const QString &summary) { m_summary = summary; }

    inline QString body() const { return m_body; }
    inline void setBody(const QString &body) { m_body = body; }

    inline QStringList actions() const { return m_actions; }
    inline void setActions(const QStringList &actions) { m_actions = actions; }

    inline QVariantMap hints() const { return m_hints; }
    inline void setHints(const QVariantMap &hints) { m_hints = hints; }

    inline QString ctime() const { return m_ctime; }
    inline void setTime(const QString & time) { m_ctime = time; }

    inline QString replacesId() const { return m_replacesId; }
    inline void setReplacesId(const QString &replacesId) { m_replacesId = replacesId; }

    inline QString timeout() const { return m_timeout; }
    inline void setTimeout(const QString &timeout) { m_timeout = timeout; }

    inline bool isTitle() { return m_isTitle; }
    inline void setIsTitle(bool is) { m_isTitle = is; }

    inline void setHideCount(int count) { m_hideCount = count; }
    inline int hideCount() const { return m_hideCount; }

    inline void setShowInNotifyCenter(bool isShow) { m_showInNotifyCenter = isShow; }
    inline bool isShowInNotifyCenter() const { return m_showInNotifyCenter; }

    inline void setShowPreview(bool show) { m_showPreview = show; }
    inline bool isShowPreview() const { return m_showPreview; }

    inline void setCurrentIndex(int idx) { m_index = idx; }
    inline int currentIndex() const { return m_index; }

    inline void setState(EnumType::BubbleState state) { m_state = state; }
    inline EnumType::BubbleState state() const { return m_state; }

    inline void setZorder(int zorder) { m_zorder = zorder; }
    inline int zorder() const { return m_zorder; }

    inline void setExpandParentRow(int row) { m_expandParentRow = row; }
    inline int expandParentRow() const { return m_expandParentRow; }

    inline void setParentPosY(double posy) { m_parentPosY = posy; }
    inline double parentPosY() const { return m_parentPosY; }

    inline bool isFlicked() { return m_isFlicked; }
    inline void setIsFlicked(bool is) { m_isFlicked = is; }
private:
    QString m_appName;
    uint m_id;
    QString m_appIcon;
    QString m_summary;
    QString m_body;
    QStringList m_actions;
    QVariantMap m_hints;
    QString m_ctime;
    QString m_replacesId;
    QString m_timeout;
    bool m_isTitle;     // 是否是标题
    int m_hideCount;    // 此条消息下面被层叠的消息数量
    bool m_showPreview;
    int m_index;
    bool m_showInNotifyCenter;
    EnumType::BubbleState m_state; // 气泡状态
    int m_zorder;   // z序
    int m_expandParentRow; // 收缩折叠的父索引行
    double m_parentPosY; // 收缩折叠父对象位置
    bool m_isFlicked;    // 是否轻扫
};

#endif // NOTIFYENTITY_H
